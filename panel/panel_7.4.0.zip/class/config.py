#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2016 宝塔软件(http://www.bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 沐落 <cjx@bt.cn>
# +-------------------------------------------------------------------
import os, sys
panelPath = os.getenv('BT_PANEL')

os.chdir(panelPath)
if not panelPath + "/class/" in sys.path:
    sys.path.insert(0, panelPath + "/class/")

import public,re,apache,json,time


try:
    from flask import request
    from BTPanel import session,admin_path_checks,cache
except : pass

try:
    import pyotp
except :
    os.system(public.get_run_pip("[PIP] install pyotp"))
    import pyotp

class config:
    _setup_path = os.getenv('BT_PANEL')
    _key_file = _setup_path+"/data/two_step_auth.txt"
    _bk_key_file = _setup_path + "/data/bk_two_step_auth.txt"
    _username_file = _setup_path + "/data/username.txt"
    _core_fle_path = _setup_path + '/data/qrcode'
    __mail_list = []
    __weixin_user = []

    def __init__(self):
        pass

    def install_module(self,get):
        """
        安装/更新消息通道模块
        @name 需要安装的模块名称
        """
        module_name = get.name
        down_url = public.get_url()

        local_path = '{}/class/msg'.format(panelPath)
        if not os.path.exists(local_path): os.makedirs(local_path)            

        sfile = '{}/{}_msg.py'.format(local_path,module_name)
        public.downloadFileByWget('{}/win/panel/msg/{}_msg.py'.format(down_url,module_name),sfile)
        if not os.path.exists(sfile): return public.returnMsg(False, '【{}】模块安装失败'.format(module_name))    
        if os.path.getsize(sfile) < 1024: return public.returnMsg(False, '【{}】模块安装失败'.format(module_name))
  
        sfile = '{}/class/msg/{}.html'.format(panelPath,module_name)
        public.downloadFileByWget('{}/win/panel/msg/{}.html'.format(down_url,module_name),sfile)
            
        return public.returnMsg(True, '【{}】模块安装成功.'.format(module_name))   
    
    def uninstall_module(self,get):
        """
        卸载消息通道模块
        @name 需要卸载的模块名称
        """
        module_name = get.name
        sfile = '{}/class/msg/{}_msg.py'.format(panelPath,module_name)
        if os.path.exists(sfile): os.remove(sfile)

        return public.returnMsg(True, '【{}】模块卸载成功'.format(module_name))   


    def get_module_template(self,get):
        """
        获取模块模板
        """
        sfile = '{}/class/msg/{}.html'.format(panelPath,get.module_name)
        if not os.path.exists(sfile):  
            return public.returnMsg(False, '模板文件不存在.')            

        shtml = public.readFile(sfile)
        return public.returnMsg(True, shtml)            

    def set_config(self,get):
        """
        设置消息通道配置
        """
        obj =  public.init_msg(get.name)               
        if not obj: return public.returnMsg(False, '设置失败，【{}】未安装'.format(get.name))            
        return obj.set_config(get)
   

    def get_msg_configs(self,get):
        """
        获取消息通道配置列表
        """
        cpath = 'data/msg.json'
        try:
            if 'force' in get or not os.path.exists(cpath):                 
                if not 'download_url' in session: session['download_url'] = public.get_url()                             
                public.downloadFileByWget('{}/win/panel/msg/msg.json'.format(session['download_url']),cpath)                           
        except : pass
                
        data = {}
        if os.path.exists(cpath):
            msgs = json.loads(public.readFile(cpath))
    
            for x in msgs:
                x['data'] = {}
                x['setup'] = False
                x['info'] = False
                key = x['name']          
                try:
                    obj =  public.init_msg(x['name'])                    
                    if obj:
                        x['setup'] = True
                        x['data'] = obj.get_config(None)
                        x['info'] = obj.get_version_info(None);
                        
                except : 
                    print(public.get_error_info())
                    pass                
                data[key] = x
        return data

    def getPanelState(self,get):
        return os.path.exists(os.getenv("BT_PANEL") + '/data/close.pl');
    
    def reload_session(self):
    
        userInfo = public.M('users').where("id=?",(1,)).field('username,password').find()
        token = public.Md5(userInfo['username'] + '/' + userInfo['password'])
        public.writeFile('data/login_token.pl',token)

        skey = 'login_token'
        cache.set(skey,token)

        sess_path = 'data/sess_files'
        if not os.path.exists(sess_path): os.makedirs(sess_path,384)

        self.clean_sess_files(sess_path)
        sess_key = public.get_sess_key()
        sess_file = os.path.join(sess_path,sess_key)
      
        public.writeFile(sess_file,str(int(time.time()+86400)))
        session['login_token'] = token


    def clean_sess_files(self,sess_path):
        '''
            @name 清理过期的sess_file
            @auther hwliang<2020-07-25>
            @param sess_path(string) sess_files目录
            @return void
        '''
        s_time = time.time()
        for fname in os.listdir(sess_path):
            try:
                if len(fname) != 32: continue
                sess_file = os.path.join(sess_path,fname)
                if not os.path.isfile(sess_file): continue
                sess_tmp = public.ReadFile(sess_file)
                if not sess_tmp:
                    if os.path.exists(sess_file):
                        os.remove(sess_file)
                if s_time > int(sess_tmp):
                    os.remove(sess_file)
            except:
                pass

    def setPassword(self,get):
        if get.password1 != get.password2: return public.returnMsg(False,'USER_PASSWORD_CHECK')
        if len(get.password1) < 5: return public.returnMsg(False,'USER_PASSWORD_LEN')
        public.M('users').where("username=?",(session['username'],)).setField('password',public.password_salt(public.md5(get.password1.strip()),username=session['username']))
        public.WriteLog('TYPE_PANEL','USER_PASSWORD_SUCCESS',(session['username'],))
        self.reload_session()
        return public.returnMsg(True,'USER_PASSWORD_SUCCESS')

    def setUsername(self,get):
        if get.username1 != get.username2: return public.returnMsg(False,'USER_USERNAME_CHECK')
        if len(get.username1) < 3: return public.returnMsg(False,'USER_USERNAME_LEN')
        public.M('users').where("username=?",(session['username'],)).setField('username',get.username1.strip())
        public.WriteLog('TYPE_PANEL','USER_USERNAME_SUCCESS',(session['username'],get.username2))
        session['username'] = get.username1
        self.reload_session()
        return public.returnMsg(True,'USER_USERNAME_SUCCESS')
    
    def setPanel(self,get):
        
        if not public.IsRestart(): return public.returnMsg(False,'EXEC_ERR_TASK');
        if get.admin_path == '': get.admin_path = '/'
        if get.admin_path != '/':
            if len(get.admin_path) < 6: return public.returnMsg(False,'安全入口地址长度不能小于6位!')
            if get.admin_path in admin_path_checks: return public.returnMsg(False,'该入口已被面板占用,请使用其它入口!')
            if not re.match("^/[\w\./-_]+$",get.admin_path):  return public.returnMsg(False,'入口地址格式不正确,示例: /my_panel')
            if get.admin_path[0] != '/': return public.returnMsg(False,'入口地址格式不正确,示例: /my_panel')

        if get.domain:
            reg = "^([\w\-\*]{1,100}\.){1,4}(\w{1,10}|\w{1,10}\.\w{1,10})$";
            if not re.match(reg, get.domain): return public.returnMsg(False,'SITE_ADD_ERR_DOMAIN');
        isReWeb = False

        oldPort = public.readFile('data/port.pl');
        if not 'port' in get:
            get.port = oldPort
        
        newPort = get.port;       
        if not re.match('^\d+$',get.port): 
            return public.returnMsg(False,get.port + '不是有效的端口(1-65535)!')

        if oldPort != get.port:
            get.port = str(int(get.port))
            if self.IsOpen(get.port):
                return public.returnMsg(False,'PORT_CHECK_EXISTS',(get.port,))
            if int(get.port) >= 65535 or  int(get.port) < 100: return public.returnMsg(False,'PORT_CHECK_RANGE');
            public.writeFile('data/port.pl',get.port)
            import firewalls
            get.ps = public.getMsg('PORT_CHECK_PS');
            fw = firewalls.firewalls();
            fw.AddAcceptPort(get);
            get.port = oldPort;
            get.id = public.M('firewall').where("port=?",(oldPort,)).getField('id');
            fw.DelAcceptPort(get);
            isReWeb = True
        
        if get.webname != session['title']: 
            session['title'] = get.webname
            public.SetConfigValue('title',get.webname)

        admin_path_file = 'data/admin_path.pl'
        admin_path = '/'
        if os.path.exists(admin_path_file): admin_path = public.readFile(admin_path_file).strip()
        if get.admin_path != admin_path:           
            public.writeFile(admin_path_file,get.admin_path)
            isReWeb = True
        
        limitip = public.readFile('data/limitip.conf');
        if get.limitip != limitip: public.writeFile('data/limitip.conf',get.limitip);
        
        public.writeFile('data/domain.conf',get.domain.strip())
        public.writeFile('data/iplist.txt',get.address)
        
        if len(get.backup_path.strip()) <= 3 or len(get.sites_path.strip()) <= 3:  return public.returnMsg(False,'网站路径和备份路径不能以磁盘为目录.')

        public.M('config').where("id=?",('1',)).save('backup_path,sites_path',(get.backup_path,get.sites_path))
        session['config']['backup_path'] = get.backup_path
        session['config']['sites_path'] = get.sites_path

        public.SetConfigValue('root_path',get.sites_path)
        if not os.path.exists(get.backup_path): 
            os.makedirs(get.backup_path)            
            public.set_file_access(get.backup_path,"IIS_IUSRS",public.file_exec)
            public.set_file_access(get.backup_path,"www",public.file_exec)
            public.set_file_access(get.backup_path,"Authenticated Users",public.file_all)
            
        if not os.path.exists(get.sites_path): 
            os.makedirs(get.sites_path)
            public.set_file_access(get.sites_path,"IIS_IUSRS",public.file_exec)
            public.set_file_access(get.sites_path,"www",public.file_exec)

        mhost = public.GetHost()
        if get.domain.strip(): mhost = get.domain
        data = {'uri':request.path,'host':mhost+':'+newPort,'status':True,'isReWeb':isReWeb,'msg':public.getMsg('PANEL_SAVE')}
        public.WriteLog('TYPE_PANEL','PANEL_SAVE',(newPort,get.domain,get.backup_path,get.sites_path,get.address,get.limitip))
        if isReWeb: public.restart_panel()
        return data
      
        
    def set_admin_path(self,get):
        get.admin_path = get.admin_path.strip()
        if get.admin_path == '': get.admin_path = '/'
        if get.admin_path != '/':
            if len(get.admin_path) < 6: return public.returnMsg(False,'安全入口地址长度不能小于6位!')
            if get.admin_path in admin_path_checks: return public.returnMsg(False,'该入口已被面板占用,请使用其它入口!')
            if not re.match("^/[\w\./-_]+$",get.admin_path):  return public.returnMsg(False,'入口地址格式不正确,示例: /my_panel')
        else:
            get.domain = public.readFile('data/domain.conf')
            if not get.domain: get.domain = '';
            get.limitip = public.readFile('data/limitip.conf')
            if not get.limitip: get.limitip = '';
            if not get.domain.strip() and not get.limitip.strip(): return public.returnMsg(False,'警告，关闭安全入口等于直接暴露你的后台地址在外网，十分危险，至少开启以下一种安全方式才能关闭：<a style="color:red;"><br>1、绑定访问域名<br>2、绑定授权IP</a>')

        admin_path_file = 'data/admin_path.pl'
        admin_path = '/'
        if os.path.exists(admin_path_file): admin_path = public.readFile(admin_path_file).strip()
        if get.admin_path != admin_path:
            public.writeFile(admin_path_file,get.admin_path)
            public.restart_panel()
        return public.returnMsg(True,'修改成功!');
    
    def setPathInfo(self,get):
        #设置PATH_INFO
        version = get.version
        type = get.type
             
        path = public.GetConfigValue('setup_path')+'/php/'+version+'/php.ini';
        conf = public.readFile(path);
        rep = "\n*\s*cgi\.fix_pathinfo\s*=\s*([0-9]+)\s*\n";
        status = '0'
        if type == 'on':status = '1'
        conf = re.sub(rep,"\ncgi.fix_pathinfo = "+status+"\n",conf)
        public.writeFile(path,conf)
        public.WriteLog("TYPE_PHP", "PHP_PATHINFO_SUCCESS",(version,type));
        public.phpReload(version);
        return public.returnMsg(True,'SET_SUCCESS');
        
    #设置文件上传大小限制
    def setPHPMaxSize(self,get):
        version = get.version
        max = get.max
        
        if int(max) < 2: return public.returnMsg(False,'PHP_UPLOAD_MAX_ERR')
        
        #设置PHP
        path = public.GetConfigValue('setup_path')+'/php/'+version+'/php.ini'
        conf = public.readFile(path)
        rep = u"\nupload_max_filesize\s*=\s*[0-9]+M"
        conf = re.sub(rep,u'\nupload_max_filesize = '+max+'M',conf)
        rep = u"\npost_max_size\s*=\s*[0-9]+M"
        conf = re.sub(rep,u'\npost_max_size = '+max+'M',conf)
        public.writeFile(path,conf)
        
        if public.get_webserver() == 'iis':
            max_limit = int(max)
            if max_limit > 400: max_limit = 400
                
            shell = '%s set config -section:requestFiltering -requestLimits.maxAllowedContentLength:%s -commitpath:apphost' % (self.get_appcmd(),max_limit * 1024 * 1024)
            os.system(shell)
        
        public.serviceReload()
        public.phpReload(version);
        public.WriteLog("TYPE_PHP", "PHP_UPLOAD_MAX",(version,max))
        return public.returnMsg(True,'SET_SUCCESS')
    
    #设置禁用函数
    def setPHPDisable(self,get):
        filename = public.GetConfigValue('setup_path') + '/php/' + get.version + '/php.ini'
        if not os.path.exists(filename): return public.returnMsg(False,'PHP_NOT_EXISTS');
        phpini = public.readFile(filename);
        rep = "disable_functions\s*=\s*.*\n"
        phpini = re.sub(rep, 'disable_functions = ' + get.disable_functions + "\n", phpini);
        public.WriteLog('TYPE_PHP','PHP_DISABLE_FUNCTION',(get.version,get.disable_functions))
        public.writeFile(filename,phpini);
        public.phpReload(get.version);
        return public.returnMsg(True,'SET_SUCCESS');
    
    def get_appcmd(self):
        appcmd = os.getenv("SYSTEMDRIVE") + '\\Windows\\System32\\inetsrv\\appcmd.exe'
        return appcmd

    #设置PHP超时时间
    def setPHPMaxTime(self,get):
        time = get.time
        version = get.version;
        if int(time) < 30 or int(time) > 86400: return public.returnMsg(False,'PHP_TIMEOUT_ERR');
        
        file = public.GetConfigValue('setup_path') + '/php/'+version+'/php.ini';
        phpini = public.readFile(file);
        rep = "max_execution_time\s*=\s*([0-9]+)\r?\n";
        phpini = re.sub(rep,"max_execution_time = "+time+"\n",phpini);
        rep = "max_input_time\s*=\s*([0-9]+)\r?\n";
        phpini = re.sub(rep,"max_input_time = "+time+"\n",phpini);
        public.writeFile(file,phpini)        
        
        if public.get_webserver() == 'iis':
            cgiPath = public.to_path(public.GetConfigValue('setup_path') + '/php/'+ version +'/php-cgi.exe')      
            public.ExecShell("%s set config -section:system.webServer/fastCgi /[fullPath='%s',arguments=''].activityTimeout:%s /commit:apphost" % (self.get_appcmd(),cgiPath,get.time))
            public.ExecShell("%s set config -section:system.webServer/fastCgi /[fullPath='%s',arguments=''].requestTimeout:%s  /commit:apphost" % (self.get_appcmd(),cgiPath,get.time))
        
        public.WriteLog("TYPE_PHP", "PHP_TIMEOUT",(version,time));
        public.serviceReload()
        public.phpReload(version);
        return public.returnMsg(True, 'SET_SUCCESS');
    
    #取FPM设置
    def getFpmConfig(self,get):
        version = get.version;
        file = public.GetConfigValue('setup_path')+"/php/"+version+"/etc/php-fpm.conf";
        conf = public.readFile(file);
        data = {}
        rep = "\s*pm.max_children\s*=\s*([0-9]+)\s*";
        tmp = re.search(rep, conf).groups();
        data['max_children'] = tmp[0];
        
        rep = "\s*pm.start_servers\s*=\s*([0-9]+)\s*";
        tmp = re.search(rep, conf).groups();
        data['start_servers'] = tmp[0];
        
        rep = "\s*pm.min_spare_servers\s*=\s*([0-9]+)\s*";
        tmp = re.search(rep, conf).groups();
        data['min_spare_servers'] = tmp[0];
        
        rep = "\s*pm.max_spare_servers \s*=\s*([0-9]+)\s*";
        tmp = re.search(rep, conf).groups();
        data['max_spare_servers'] = tmp[0];
        
        rep = "\s*pm\s*=\s*(\w+)\s*";
        tmp = re.search(rep, conf).groups();
        data['pm'] = tmp[0];
        
        return data

    #设置
    def setFpmConfig(self,get):
        version = get.version
        max_children = get.max_children
        start_servers = get.start_servers
        min_spare_servers = get.min_spare_servers
        max_spare_servers = get.max_spare_servers
        pm = get.pm
        
        file = public.GetConfigValue('setup_path')+"/php/"+version+"/etc/php-fpm.conf";
        conf = public.readFile(file);
        
        rep = "\s*pm.max_children\s*=\s*([0-9]+)\s*";
        conf = re.sub(rep, "\npm.max_children = "+max_children, conf);
        
        rep = "\s*pm.start_servers\s*=\s*([0-9]+)\s*";
        conf = re.sub(rep, "\npm.start_servers = "+start_servers, conf);
        
        rep = "\s*pm.min_spare_servers\s*=\s*([0-9]+)\s*";
        conf = re.sub(rep, "\npm.min_spare_servers = "+min_spare_servers, conf);
        
        rep = "\s*pm.max_spare_servers \s*=\s*([0-9]+)\s*";
        conf = re.sub(rep, "\npm.max_spare_servers = "+max_spare_servers+"\n", conf);
        
        rep = "\s*pm\s*=\s*(\w+)\s*";
        conf = re.sub(rep, "\npm = "+pm+"\n", conf);
        
        public.writeFile(file,conf)
        public.phpReload(version);
        public.WriteLog("TYPE_PHP",'PHP_CHILDREN', (version,max_children,start_servers,min_spare_servers,max_spare_servers));
        return public.returnMsg(True, 'SET_SUCCESS');
    
    #同步时间
    def syncDate(self,get):
        dateStr = public.HttpGet(public.GetConfigValue('home') + '/api/index/get_win_date')
        arrs = dateStr.split(' ')
        os.system('date {} && time {}'.format(arrs[0],arrs[1]))

        public.WriteLog("TYPE_PANEL", "DATE_SUCCESS");
        return public.returnMsg(True,"DATE_SUCCESS");
        
    def IsOpen(self,port):
        #检查端口是否占用
        import socket
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:
            s.connect(('127.0.0.1',int(port)))
            s.shutdown(2)
            return True
        except:
            return False
    
    #设置是否开启监控
    def SetControl(self,get):
        try:
            if hasattr(get,'day'): 
                get.day = int(get.day);
                get.day = str(get.day);
                if(get.day < 1): return public.returnMsg(False,"CONTROL_ERR");
        except:
            pass

        filename = 'data/control.conf';
        if get.type == '1':
            public.writeFile(filename,get.day);
            public.WriteLog("TYPE_PANEL",'CONTROL_OPEN',(get.day,));
        elif get.type == '0':
            if os.path.exists(filename): os.remove(filename)
            public.WriteLog("TYPE_PANEL", "CONTROL_CLOSE");
        elif get.type == 'del':
            if not public.IsRestart(): return public.returnMsg(False,'EXEC_ERR_TASK');
            os.system("sc stop btTask")
            os.remove("data/system.db")
            import db;
            sql = db.Sql()
            result = sql.dbfile('system').create('system');
            os.system("net start btTask")
            public.WriteLog("TYPE_PANEL", "清理监控记录");
            return public.returnMsg(True,"记录清理成功");
            
        else:
            data = {}
            if os.path.exists(filename):
                try:
                    data['day'] = int(public.readFile(filename));
                except:
                    data['day'] = 30;
                data['status'] = True
            else:
                data['day'] = 30;
                data['status'] = False
            return data        
        return public.returnMsg(True,"SET_SUCCESS");
            
    #关闭面板
    def ClosePanel(self,get):
        filename = 'data/close.pl'
        if os.path.exists(filename):
            os.remove(filename)
            return public.returnMsg(True,'开启成功')
        import firewalls
        data = firewalls.firewalls().GetSshInfo(get)
        print(data)
        if not data['status']:
            return public.returnMsg(False,'请勿同时关闭远程桌面和面板！');
        public.writeFile(filename,'True');
        return public.returnMsg(True,'PANEL_CLOSE');
    
    

    #设置二级密码
    def SetPanelLock(self,get):
        path = 'data/lock';
        if not os.path.exists(path):
            public.ExecShell('mkdir ' + path);
            public.ExecShell("chmod 600 " + path);
            public.ExecShell("chown root.root " + path);
        
        keys = ['files','tasks','config'];
        for name in keys:
            filename = path + '/' + name + '.pl';
            if hasattr(get,name):
                public.writeFile(filename,'True');
            else:
                if os.path.exists(filename): os.remove(filename);

    
    #设置模板
    def SetTemplates(self,get):
        public.writeFile('data/templates.pl',get.templates);
        return public.returnMsg(True,'SET_SUCCESS');
    
    #生成Token
    def SetToken(self,get):
        data = {}
        data[''] = public.GetRandomString(24);
    
    
    #获取PHP配置参数
    def GetPHPConf(self,get):
        gets = [
                {'name':'short_open_tag','type':1,'ps':public.getMsg('PHP_CONF_1')},
                {'name':'asp_tags','type':1,'ps':public.getMsg('PHP_CONF_2')},
                {'name':'max_execution_time','type':2,'ps':public.getMsg('PHP_CONF_4')},
                {'name':'max_input_time','type':2,'ps':public.getMsg('PHP_CONF_5')},
                {'name':'memory_limit','type':2,'ps':public.getMsg('PHP_CONF_6')},
                {'name':'post_max_size','type':2,'ps':public.getMsg('PHP_CONF_7')},
                {'name':'file_uploads','type':1,'ps':public.getMsg('PHP_CONF_8')},
                {'name':'upload_max_filesize','type':2,'ps':public.getMsg('PHP_CONF_9')},
                {'name':'max_file_uploads','type':2,'ps':public.getMsg('PHP_CONF_10')},
                {'name':'default_socket_timeout','type':2,'ps':public.getMsg('PHP_CONF_11')},
                {'name':'error_reporting','type':3,'ps':public.getMsg('PHP_CONF_12')},
                {'name':'display_errors','type':1,'ps':public.getMsg('PHP_CONF_13')},
                {'name':'cgi.fix_pathinfo','type':0,'ps':public.getMsg('PHP_CONF_14')},
                {'name':'date.timezone','type':3,'ps':public.getMsg('PHP_CONF_15')}
                ]
        phpini = public.readFile(public.GetConfigValue('setup_path') + '/php/' + get.version + '/php.ini');
        
        result = []
        for g in gets:
            rep = g['name'] + '\s*=\s*\"?([/0-9A-Za-z_& ~]+)(\"?|\s*;?|\r?\n)';
            tmp = re.search(rep,phpini)
            if not tmp: continue;
            g['value'] = tmp.groups()[0].strip();
            result.append(g);
        
        return result;


    def get_php_config(self,get):
        #取PHP配置
        get.version = get.version.replace('.','')
        file = public.GetConfigValue('setup_path') + "/php/"+get.version+"/php.ini"
        phpini = public.readFile(file)
        data = {}
        try:
            rep = "upload_max_filesize\s*=\s*([0-9]+)M"
            tmp = re.search(rep,phpini).groups()
            data['max'] = tmp[0]
        except:
            data['max'] = '50'

        try:
            rep = 'max_execution_time\s*=\s*([0-9A-Za-z_& ~]+)(\s*;?|\r?\n)'
            tmp = re.search(rep,phpini).groups()
            data['maxTime'] = tmp[0]
        except :
            data['maxTime'] =0

        try:
            rep = r"\n;*\s*cgi\.fix_pathinfo\s*=\s*([0-9]+)\s*\n"
            tmp = re.search(rep,phpini).groups()
            
            if tmp[0] == '1':
                data['pathinfo'] = True
            else:
                data['pathinfo'] = False
        except:
            data['pathinfo'] = False
        
        return data
    
    #提交PHP配置参数
    def SetPHPConf(self,get):
        gets = ['display_errors','cgi.fix_pathinfo','date.timezone','short_open_tag','asp_tags','max_execution_time','max_input_time','memory_limit','post_max_size','file_uploads','upload_max_filesize','max_file_uploads','default_socket_timeout','error_reporting']
        filename = public.GetConfigValue('setup_path') + '/php/' + get.version + '/php.ini';
        phpini = public.readFile(filename);
        for g in gets:
            if get[g]:
                rep = g + '\s*=\s*(.+)\r?\n';
                val = g+' = ' + get[g] + '\n';
                phpini = re.sub(rep,val,phpini);
        
        public.writeFile(filename,phpini);
        return public.returnMsg(True,'SET_SUCCESS');
   

    #获取配置
    def get_config(self,get):
        try:
            if 'config' in session: 
                session['config']['distribution'] = public.get_system_version(True)
                session['webserver'] = public.get_webserver()
                return session['config']
        except :pass
                
        data = public.M('config').where("id=?",('1',)).field('webserver,sites_path,backup_path,status,mysql_root').find(); 
        data['webserver'] = public.get_webserver()
        data['distribution'] = public.get_system_version(True)
        return data

    #取面板错误日志
    def get_error_logs(self,get):
        return public.GetNumLines('logs/error.log',2000)
            
    def GetApacheValue(self,get):
        a = apache.apache()
        return a.GetApacheValue()

    def SetApacheValue(self,get):
        a = apache.apache()
        return a.SetApacheValue(get)
        
    def get_ipv6_listen(self,get):
        return os.path.exists('data/ipv6.pl')

    def set_ipv6_status(self,get):
        ipv6_file = 'data/ipv6.pl'
        if self.get_ipv6_listen(get):
            os.remove(ipv6_file)
            public.WriteLog('面板设置','关闭面板IPv6兼容!')
        else:
            public.writeFile(ipv6_file,'True')
            public.WriteLog('面板设置','开启面板IPv6兼容!')
        public.restart_panel()
        return public.returnMsg(True,'设置成功!')

    #设置debug模式
    def set_debug(self,get):
        debug_path = 'data/debug.pl'
        if os.path.exists(debug_path):
            t_str = '关闭'
            os.remove(debug_path)
        else:
            t_str = '开启'
            public.writeFile(debug_path,'True')
        public.WriteLog('面板配置','%s开发者模式(debug)' % t_str)
        public.restart_panel()
        return public.returnMsg(True,'设置成功!')

    def get_token(self,get):      
        import panelApi
        return panelApi.panelApi().get_token(get)

    def set_token(self,get):
        import panelApi
        return panelApi.panelApi().set_token(get)

    def get_tmp_token(self,get):
        import panelApi
        return panelApi.panelApi().get_tmp_token(get)

    #获取BasicAuth状态
    def get_basic_auth_stat(self,get):
        path = 'config/basic_auth.json'
        is_install = True
        if not os.path.exists(path): return {"basic_user":"","basic_pwd":"","open":False,"is_install":is_install}
        ba_conf = json.loads(public.readFile(path))
        ba_conf['is_install'] = is_install
        return ba_conf

    #设置BasicAuth
    def set_basic_auth(self,get):
        is_open = False
        if get.open == 'True': is_open = True
        tips = '_bt.cn'
        path = 'config/basic_auth.json'
        ba_conf = None
        if os.path.exists(path):
            ba_conf = json.loads(public.readFile(path))

        if not ba_conf: 
            ba_conf = {"basic_user":public.md5(get.basic_user.strip() + tips),"basic_pwd":public.md5(get.basic_pwd.strip() + tips),"open":is_open}
        else:
            if get.basic_user: ba_conf['basic_user'] = public.md5(get.basic_user.strip() + tips)
            if get.basic_pwd: ba_conf['basic_pwd'] = public.md5(get.basic_pwd.strip() + tips)
            ba_conf['open'] = is_open
        
        public.writeFile(path,json.dumps(ba_conf))
        
        public.WriteLog('面板设置','设置BasicAuth状态为: %s' % is_open)
        public.set_server_status("btTask","restart");
        public.writeFile('data/reload.pl','True')
        return public.returnMsg(True,"设置成功!")

    #二次认证
    def _create_key(self):

        get_token = pyotp.random_base32() # returns a 16 character base32 secret. Compatible with Google Authenticator
        public.writeFile(self._key_file,get_token)
        username = self.get_random()
        public.writeFile(self._username_file, username)

    def get_key(self,get):
        key = public.readFile(self._key_file)
        username = public.readFile(self._username_file)
        if not key:
            return public.returnMsg(False, "秘钥不存在，请开启后再试")
        if not username:
            return public.returnMsg(False, "用户名不存在，请开启后再试")
        return {"key":key,"username":username}

    def get_random(self):
        import random
        seed = "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
        sa = []
        for i in range(8):
            sa.append(random.choice(seed))
        salt = ''.join(sa)
        return salt

    def set_two_step_auth(self,get):
        if not hasattr(get,"act") or not get.act:
            return public.returnMsg(False, "请输入操作方式")
        if get.act == "1":
            if not os.path.exists(self._core_fle_path):
                os.makedirs(self._core_fle_path)
            username = public.readFile(self._username_file)
            if not os.path.exists(self._bk_key_file):
                secret_key = public.readFile(self._key_file)
                if not secret_key or not username:
                    self._create_key()
            else:
                os.rename(self._bk_key_file,self._key_file)
            secret_key = public.readFile(self._key_file)
            username = public.readFile(self._username_file)
            local_ip = public.GetLocalIp()
            if not secret_key:
                return public.returnMsg(False,"生成key或username失败，请检查硬盘空间是否不足或目录无法写入[ {} ]".format(self._setup_path+"/data/"))
            try:
                try:
                    panel_name = json.loads(public.readFile(self._setup_path+'/config/config.json'))['title']
                except:
                    panel_name = '宝塔Windows面板'
                data = pyotp.totp.TOTP(secret_key).provisioning_uri(username, issuer_name=panel_name+'--'+local_ip)
                public.writeFile(self._core_fle_path+'/qrcode.txt',str(data))
                return public.returnMsg(True, "开启成功")
            except Exception as e:
                return public.returnMsg(False, e)
        else:
            if os.path.exists(self._key_file):
                os.rename(self._key_file,self._bk_key_file)
            return public.returnMsg(True, "关闭成功")

    # 检测是否开启双因素验证
    def check_two_step(self,get):
        secret_key = public.readFile(self._key_file)
        if not secret_key:
            return public.returnMsg(False, "没有开启二步验证")
        return public.returnMsg(True, "已经开启二步验证")
        
    # 读取二维码data
    def get_qrcode_data(self,get):
        data = public.readFile(self._core_fle_path + '/qrcode.txt')
        if data:
            return data
        return public.returnMsg(True, "没有二维码数据，请重新开启")


    #取用户列表
    def get_users(self,args):
        data = public.M('users').field('id,username').select()
        return data

    # 创建新用户
    def create_user(self,args):
        if session['uid'] != 1: return public.returnMsg(False,'没有权限!')
        if len(args.username) < 2: return public.returnMsg(False,'用户名不能少于2位')
        if len(args.password) < 8: return public.returnMsg(False,'密码不能少于8位')
        pdata = {
            "username": args.username.strip(),
            "password": public.password_salt(public.md5(args.password.strip()),username=args.username.strip())
        }

        if(public.M('users').where('username=?',(pdata['username'],)).count()):
            return public.returnMsg(False,'指定用户名已存在!')
        
        if(public.M('users').insert(pdata)):
            public.WriteLog('用户管理','创建新用户{}'.format(pdata['username']))
            return public.returnMsg(True,'创建新用户{}成功!'.format(pdata['username']))
        return public.returnMsg(False,'创建新用户失败!')

    # 删除用户
    def remove_user(self,args):
        if session['uid'] != 1: return public.returnMsg(False,'没有权限!')
        if int(args.id) == 1: return public.returnMsg(False,'不能删除初始默认用户!')
        username = public.M('users').where('id=?',(args.id,)).getField('username')
        if not username: return public.returnMsg(False,'指定用户不存在!')
        if(public.M('users').where('id=?',(args.id,)).delete()):
            public.WriteLog('用户管理','删除用户[{}]'.format(username))
            return public.returnMsg(True,'删除用户{}成功!'.format(username))
        return public.returnMsg(False,'用户删除失败!')

    # 修改用户
    def modify_user(self,args):
        if session['uid'] != 1: return public.returnMsg(False,'没有权限!')
        username = public.M('users').where('id=?',(args.id,)).getField('username')
        pdata = {}
        if 'username' in args:
            if len(args.username) < 2: return public.returnMsg(False,'用户名不能少于2位')
            pdata['username'] = args.username.strip()

        if 'password' in args:
            if args.password:
                if len(args.password) < 8: return public.returnMsg(False,'密码不能少于8位')
                pdata['password'] = public.password_salt(public.md5(args.password.strip()),username=username)

        if(public.M('users').where('id=?',(args.id,)).update(pdata)):
            public.WriteLog('用户管理',"编辑用户{}".format(username))
            return public.returnMsg(True,'修改成功!')
        return public.returnMsg(False,'没有提交修改!')


    # 是否显示软件推荐
    def show_recommend(self,get):
        pfile = 'data/not_recommend.pl'
        if os.path.exists(pfile):
            os.remove(pfile)
        else:
            public.writeFile(pfile,'True')
        return public.returnMsg(True,'设置成功!')


    def auto_update_panel(self,get):
        """
        开启和关闭自动更新
        """
        echo = public.md5('auto_update_panel')

        cronPath = '{}/cron/{}'.format(public.GetConfigValue('setup_path'),echo)
        shell = public.get_run_python('[PYTHON] -u %s/tools.py auto_update_panel ' % (public.GetConfigValue('setup_path')))

        crontab = public.M('crontab').where('echo=?',(echo,)).find()
        if not crontab:           
            public.writeFile(cronPath,shell)
            public.M('crontab').add('name,type,where1,where_hour,where_minute,echo,addtime,status,save,backupTo,sType,sName,sBody,urladdress',("自动更新面板【宝塔面板】",'day','','0','10',echo,time.strftime('%Y-%m-%d %X',time.localtime()),1,'','localhost','toShell','',shell,''))

            return public.returnMsg(True,'开启自动更新成功，通过计划任务可以设置检查时间段.') 
        else:
            public.M('crontab').where('echo=?',(echo,)).delete()
            if os.path.exists(cronPath): os.remove(cronPath)
            
            return public.returnMsg(True,'关闭自动更新成功!') 

        
        #获取临时登录列表
    def get_temp_login(self,args):
        '''
            @name 获取临时登录列表
            @author hwliang<2020-09-2>
            @return dict
        '''
        if 'tmp_login_expire' in session: return public.returnMsg(False,'没有权限')
        public.M('temp_login').where('state=? and expire<?',(0,int(time.time()))).setField('state',-1)
        callback = ''
        if 'tojs' in args:
            callback = args.tojs
        p = 1
        if 'p' in args:
            p = int(args.p)
        rows =12
        if 'rows' in args:
            rows = int(args.rows)
        count = public.M('temp_login').count()
        data = {}
        page_data = public.get_page(count,p,rows,callback)
        data['page'] = page_data['page']
        data['data'] = public.M('temp_login').limit(page_data['shift'] + ',' + page_data['row']).order('id desc').field('id,addtime,expire,login_time,login_addr,state').select()
        for i in range(len(data['data'])):
            data['data'][i]['online_state'] = os.path.exists('data/session/{}'.format(data['data'][i]['id']))
        return data

    #设置临时登录
    def set_temp_login(self,args):
        '''
            @name 设置临时登录
            @author hwliang<2020-09-2>
            @return dict
        '''
        if 'tmp_login_expire' in session: return public.returnMsg(False,'没有权限')
        s_time = int(time.time())
        public.M('temp_login').where('state=? and expire>?',(0,s_time)).delete()
        token = public.GetRandomString(48)
        salt = public.GetRandomString(12)
        
        pdata = {
            'token': public.md5(token + salt),
            'salt': salt,
            'state':0,
            'login_time':0,
            'login_addr':'',
            'expire':s_time + 3600,
            'addtime':s_time
        }

        if not public.M('temp_login').count():
            pdata['id'] = 101

        if public.M('temp_login').insert(pdata):
            public.WriteLog('面板设置','生成临时连接,过期时间:{}'.format(public.format_date(times = pdata['expire'])))
            return {'status':True,'msg':"临时连接已生成",'token':token,'expire':pdata['expire']}
        return public.returnMsg(False,'连接生成失败')

    #删除临时登录
    def remove_temp_login(self,args):
        '''
            @name 删除临时登录
            @author hwliang<2020-09-2>
            @param args<dict_obj>{
                id: int<临时登录ID>
            }
            @return dict
        '''
        if 'tmp_login_expire' in session: return public.returnMsg(False,'没有权限')
        id = int(args.id)
        if public.M('temp_login').where('id=?',(id,)).delete():
            public.WriteLog('面板设置','删除临时登录连接')
            return public.returnMsg(True,'删除成功')
        return public.returnMsg(False,'删除失败')


    #强制弹出指定临时登录
    def clear_temp_login(self,args):
        '''
            @name 强制登出
            @author hwliang<2020-09-2>
            @param args<dict_obj>{
                id: int<临时登录ID>
            }
            @return dict
        '''
        if 'tmp_login_expire' in session: return public.returnMsg(False,'没有权限')
        id = int(args.id)
        s_file = 'data/session/{}'.format(id)
        if os.path.exists(s_file):
            os.remove(s_file)
            public.WriteLog('面板设置','强制弹出临时用户：{}'.format(id))
            return public.returnMsg(True,'已强制退出临时用户：{}'.format(id))
        public.returnMsg(False,'指定用户当前不是登录状态!')


    #查看临时授权操作日志
    def get_temp_login_logs(self,args):
        '''
            @name 查看临时授权操作日志
            @author hwliang<2020-09-2>
            @param args<dict_obj>{
                id: int<临时登录ID>
            }
            @return dict
        '''
        if 'tmp_login_expire' in session: return public.returnMsg(False,'没有权限')
        id = int(args.id)
        data = public.M('logs').where('uid=?',(id,)).order('id desc').select()
        return data


    # 是否显示工单
    def show_workorder(self,get):
        pfile = 'data/not_workorder.pl'
        if os.path.exists(pfile):
            os.remove(pfile)
        else:
            public.writeFile(pfile,'True')
        return public.returnMsg(True,'设置成功!')


    """
    引用云厂商模块
    @cloud_name 模块名称
    @s 函数名
    """
    def get_cloud_data(self,get):
        try:
            spath = '{}/class/cloud'.format(panelPath)
            if not os.path.exists(spath): return public.returnMsg(False,'模块不存在1')         

            cloud_name = get['cloud_name']
            sys.path.insert(0, spath)
            module = __import__(cloud_name)
            try:
                public.mod_reload(module)
            except: pass
            moduleObj = eval('{}.{}()'.format(module,module));
            if not hasattr(moduleObj,get.s): return public.returnMsg(False,"缺少函数{}".format(get.s));

            execStr = 'moduleObj.' + get.s + '(get)'
            return eval(execStr);
        except :
            return public.returnMsg(False,public.get_error_info())
        

    """
    获取面板配置
    """
    def get_panel_config(self,get):
        import system
        data = system.system().GetConcifInfo()
        data['workorder'] = not os.path.exists('data/not_workorder.pl')
        data['recommend'] = not os.path.exists('data/not_recommend.pl')
        data['basic_auth'] = self.get_basic_auth_stat(None)
        data['lan'] = public.GetLan('config')
        import wxapp
        data['wx'] = wxapp.wxapp().get_user_info(None)['msg']
        data['api'] = ''
        if self.get_token(None)['open']: data['api'] = 'checked' 
        
        return data


      #获取面板证书
    def GetPanelSSL(self,get):
        cert = {}
        cert['privateKey'] = public.readFile('ssl/privateKey.pem')
        cert['certPem'] = public.readFile('ssl/certificate.pem')
        cert['rep'] = os.path.exists('ssl/input.pl')
        return cert
    
    #保存面板证书
    def SavePanelSSL(self,get):
        keyPath = 'ssl/privateKey.pem'
        certPath = 'ssl/certificate.pem'
        checkCert = 'data/cert.pl'
        public.writeFile(checkCert,get.certPem)
        if get.privateKey:
            public.writeFile(keyPath,get.privateKey)
        if get.certPem:
            public.writeFile(certPath,get.certPem)

        if not public.get_cert_data(certPath): return public.returnMsg(False,'证书错误,请检查!')
        public.writeFile('ssl/input.pl','True')
        return public.returnMsg(True,'证书已保存!')

     #设置面板SSL
    def SetPanelSSL(self,get):
        path = '{}/ssl'.format(panelPath)
        if not os.path.exists(path): os.makedirs(path)
            
        sslConf = 'data/ssl.pl'
        if hasattr(get,"certPem"):            
            ret = self.SavePanelSSL(get)
            if not ret['status']: return ret

            public.writeFile(sslConf,'True')
            return public.returnMsg(True,'PANEL_SSL_OPEN')
        else:           
            if os.path.exists(sslConf):
                os.remove(sslConf)
                return public.returnMsg(True,'PANEL_SSL_CLOSE')
            else:             
                try:
                    if not self.CreateSSL(): return public.returnMsg(False,'PANEL_SSL_ERR')
                    public.writeFile(sslConf,'True')
                except:
                    return public.returnMsg(False,'PANEL_SSL_ERR')
                return public.returnMsg(True,'PANEL_SSL_OPEN')
    #自签证书
    def CreateSSL(self):
        if os.path.exists('ssl/input.pl'): return True
        import OpenSSL
        key = OpenSSL.crypto.PKey()
        key.generate_key(OpenSSL.crypto.TYPE_RSA, 2048)
        cert = OpenSSL.crypto.X509()
        cert.set_serial_number(0)
        cert.get_subject().CN = public.GetLocalIp()
        cert.set_issuer(cert.get_subject())
        cert.gmtime_adj_notBefore( 0 )
        cert.gmtime_adj_notAfter(86400 * 3650)
        cert.set_pubkey( key )
        cert.sign( key, 'md5' )
        cert_ca = OpenSSL.crypto.dump_certificate(OpenSSL.crypto.FILETYPE_PEM, cert)
        private_key = OpenSSL.crypto.dump_privatekey(OpenSSL.crypto.FILETYPE_PEM, key)
        if len(cert_ca) > 100 and len(private_key) > 100:
            print(type(private_key),private_key)
            if type(private_key) == bytes: private_key = private_key.decode()
            if type(cert_ca) == bytes: cert_ca = cert_ca.decode()                
            public.writeFile('ssl/certificate.pem',cert_ca)
            public.writeFile('ssl/privateKey.pem',private_key)
            return True
        return False


    def set_ssl_verify(self,get):
        """
        设置双向认证
        """
        sslConf = 'data/ssl_verify.pl'
        status = int(get.status)
        if status:
            if not os.path.exists('data/ssl.pl'): return public.returnMsg(False,'需要先开启面板SSL功能!')                
            public.writeFile(sslConf,'True')
        else:
            if os.path.exists(sslConf): os.remove(sslConf)

        if 'crl' in get and 'ca' in get:            
            crl = 'ssl/crl.pem'
            ca = 'ssl/ca.pem'
        
            if get.crl:
                public.writeFile(crl,get.crl.strip())
            if get.ca:
                public.writeFile(ca,get.ca.strip())
            return public.returnMsg(True,'面板双向认证证书已保存!')
        else:
            msg = '开启'
            if not status:msg = '关闭'
            return public.returnMsg(True,'面板双向认证{}成功!'.format(msg))

    def get_ssl_verify(self,get):
        """
        获取双向认证
        """
        result = {'status':False,'ca':'','crl':''}
        sslConf = 'data/ssl_verify.pl'
        if os.path.exists(sslConf): result['status'] = True
        
        ca = 'ssl/ca.pem'
        crl = 'ssl/crl.pem'
        if os.path.exists(crl): 
            result['crl'] = public.readFile(crl)
        if os.path.exists(crl): 
            result['ca'] = public.readFile(ca)
        return result
            

    def get_login_type(self,get):
        """
        获取所有登录方式
        """        
        return public.get_login_type()

    def set_login_type(self,get):
        """
        设置登录方式开关
        """      
        if not 'login_type' in get: 
            return public.returnMsg(False,'缺少必要参数login_type!')

        data = public.get_login_type()
        data[get.login_type] = int(get.status)
        public.writeFile('data/login_type.pl',json.dumps(data))

        return public.returnMsg(True,'保存成功.')

    
    def set_click_logs(self,get):

        path = '{}/logs/click'.format(public.get_panel_path())
        if not os.path.exists(path): os.makedirs(path)
        
        file = "{}/{}.json".format(path,public.format_date(format = "%Y-%m-%d"))
        try:
            ndata = json.loads(get['ndata'])          
        except :ndata = {}

        try:
            data = json.loads(public.readFile(file))
        except : data = {}

        for x in ndata:            
            if not x in data: data[x] = 0      
            data[x] += ndata[x]
     
        public.writeFile(file,json.dumps(data))
        return data