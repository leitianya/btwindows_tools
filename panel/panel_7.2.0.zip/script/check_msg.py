#coding: utf-8
import sys,os,time
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
sys.path.insert(0,"class/")
import public
import http_requests
http_requests.DEFAULT_TYPE = 'src'
os.environ['BT_TASK'] = '1'

import panelMessage
import re,config
msgObj = panelMessage.panelMessage()
data = msgObj.get_messages()
confObj = None

for x in data:
    if x['level'] in ['danger', 'error'] and not x['send'] and x['retry_num'] < 5:
        msg = '服务器IP【{}】: {}'.format(
            public.GetLocalIp(), re.sub('，?<a\s*.+</a>', '', x['msg']))
        is_send = False

        if not confObj:confObj = config.config()

        objs = confObj.get_msg_configs(None)  
        for key in objs:
            if objs[key]['setup'] == True:                        
                module = public.init_msg(objs[key]['name'])
                ret = module.send_msg(msg)                        
                if ret['status']: is_send = True
        pdata = {}
        if is_send:
            pdata['send'] = 1
            pdata['retry_num'] = 0
        else:
            pdata['send'] = 0
            pdata['retry_num'] = x['retry_num'] + 1

        msgObj.set_send_status(x['id'], pdata)
        time.sleep(5)