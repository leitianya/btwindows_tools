# coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: lkq <lkq@bt.cn>
# | Author: cjxin <cjx@bt.cn>
# +-------------------------------------------------------------------
# +--------------------------------------------------------------------
# |   宝塔webshell 内置扫描
# +--------------------------------------------------------------------
import sys, os
panelPath = os.getenv('BT_PANEL')
os.chdir(panelPath)
sys.path.insert(0,panelPath + "/class/")
import public,hashlib,os,sys,json,time,re

class webshell_check:

    _rule_path = panelPath + '/data/webshell_rule.json'
    _exts = ['php','asp','aspx']
    def __init__(self):    
        if not os.path.exists(self._rule_path):
            rule=["@\\$\\_\\(\\$\\_", "\\$\\_=\"\"", "\\${'\\_'", "@preg\\_replace\\((\")*\\/(\\S)*\\/e(\")*,\\$_POST\\[\\S*\\]", "base64\\_decode\\(\\$\\_", "'e'\\.'v'\\.'a'\\.'l'", "\"e\"\\.\"v\"\\.\"a\"\\.\"l\"", "\"e\"\\.\"v\"\\.\"a\"\\.\"l\"", "\\$(\\w)+\\(\"\\/(\\S)+\\/e", "\\(array\\)\\$_(POST|GET|REQUEST|COOKIE)", "\\$(\\w)+\\(\\${", "@\\$\\_=", "\\$\\_=\\$\\_", "chr\\((\\d)+\\)\\.chr\\((\\d)+\\)", "phpjm\\.net", "cha88\\.cn", "c99shell", "phpspy", "Scanners", "cmd\\.php", "str_rot13", "webshell", "EgY_SpIdEr", "tools88\\.com", "SECFORCE", "eval\\(('|\")\\?>", "preg_replace\\(\"\\/\\.\\*\\/e\"", "assert\\(('|\"|\\s*)\\$", "eval\\(gzinflate\\(", "gzinflate\\(base64_decode\\(", "eval\\(base64_decode\\(", "eval\\(gzuncompress\\(", "ies\",gzuncompress\\(\\$", "eval\\(gzdecode\\(", "eval\\(str_rot13\\(", "gzuncompress\\(base64_decode\\(", "base64_decode\\(gzuncompress\\(", "eval\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)", "assert\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)", "require\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)", "require_once\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)", "include\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)", "include_once\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)", "call_user_func\\((\"|')assert(\"|')", "call_user_func\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)", "\\$_(POST|GET|REQUEST|COOKIE)\\[([^\\]]+)\\]\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)\\[", "echo\\(file_get_contents\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)", "file_put_contents\\(('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)\\[([^\\]]+)\\],('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)", "fputs\\(fopen\\((.+),('|\")w('|\")\\),('|\"|\\s*)\\$_(POST|GET|REQUEST|COOKIE)\\[", "SetHandlerapplication\\/x-httpd-php", "php_valueauto_prepend_file", "php_valueauto_append_file"]
            public.WriteFile(self._rule_path,json.dumps(rule))

    def get_rule(self):
        """
        获取扫描规则
        """
        ret = []
        if os.path.exists(self._rule_path):
            try:
                data = json.loads(public.ReadFile(self._rule_path))
                return data
            except:
                return False
        else:
            return False

    def get_file_list(self,path, flist,total_size):     
        """
        递归获取目录所有文件列表
        @path 目录路径
        @flist 返回文件列表
        @total_size 返回总文件大小
        """
        if os.path.exists(path):        
            files = os.listdir(path)            
            for file in files:
                if os.path.isdir(path + '/' + file):
                    self.get_file_list(path + '/' + file, flist,total_size)
                else:
                    for x in self._exts:
                        if file.lower()[-len(x):] == x:
                            flist.append(path + '/' + file)
                            total_size += os.path.getsize(path + '/' + file)
        return True


    def getdir_list(self, path):
        """
        获取所有扫描目录文件列表
        """
        file_list = []
        total_size = 0
        self.get_file_list(path,file_list,total_size)

        return file_list,total_size

    def scan(self, filelist, rule):
        """
        扫描本地文件规则
        """
        nlist = []
        for file in filelist:
            try:
                data = public.readFile(file)
                for r in rule:
                    if re.compile(r).findall(data):                   
                        nlist.append(file)
            except :pass
            
        return nlist


    def upload_shell(self,data):
        """
        上传webshell
        @data 本地验证文件列表
        """
        flist = []
        scanner = {}
        try:
            scanner = json.loads(public.readFile('data/scanner.json'))
        except :pass 

        for i in data:
            if self.upload_file_url(i):
                file_path = i.replace('\\','/')
                flist.append(file_path)                   
                scanner[file_path] = public.Md5(public.readFile(file_path))                
        public.writeFile('data/scanner.json',json.dumps(scanner))
        return flist


    def san_dir(self, path, send = 'mail'):
        """
        木马查杀扫描目录
        @path 需要扫描的目录
        @send 消息通道通知模块
        """           
        flist,total_size = self.getdir_list(path)
        if total_size > 10737418240 : #不检测大于10G的目录
            print("目录文件大10GB，跳过本次扫描")
            return 

        if len(flist) <= 0:
            print('目录扫描失败，请检查目录是否存在：'+ '、'.join(self._exts) + '类型文件')
            return        
            
        rule = self.get_rule()
        if not rule: 
            print("规则为空或者规则文件错误")
            return

        print("----------------------------------------------------------------------------")
        time_data = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        print("|-开始查杀目录【{}】，{}".format(path,time_data))

        nlist = self.scan(flist, rule)
        if len(nlist) > 0:   
            shell_list = self.upload_shell(nlist)
            if len(shell_list) > 0:
                msg = "webshell查杀发现【%s】目录中存在木马如下:【%s】"%(path, ','.join(shell_list))

                obj = public.init_msg(send)
                if not obj: 
                    msg = '消息通道【{}】未正确配置，请检查.';
                else:                   
                    obj.send_msg(msg)
                print('|-' + msg)
                public.WriteLog('宝塔内置webshell查杀',msg)
                return True
        msg = '查杀【{}】目录完毕,未找到可疑文件.'.format(path)
        print('|-' + msg)
        public.WriteLog('宝塔内置webshell查杀',msg)
        return True

    def san_site(self,siteName, send = 'mail'):
        """
        扫描站点木马
        """
        find = public.M('sites').where("name=?",(siteName,)).field('id,name,path').find();
        if not find: return False
        return self.san_dir(find['path'],send)

    def webshellchop(self,filename):
        try:
            upload_url = "https://webshellchop.chaitin.cn/"
            size = os.path.getsize(filename)
            if size > 1024000:return False
            files = {'inputfile': open(filename, 'r')}
            import requests
            upload_data = {"fileId": '111.php', "initialPreview": "[]", "initialPreviewConfig": "[]","initialPreviewThumbTags":"[]"}
            upload_res = requests.post(upload_url, upload_data, files=files,timeout=10).json()
            if upload_res['data']['level']==5:
                print('%s文件为木马' % filename)
                self.send_baota2(filename)
                return True
            elif upload_res['data']['level']>=3:
                print('%s可疑文件,建议手工检查' % filename)
                self.send_baota2(filename)
                return False
        except:
            return False


    def upload_file_url(self, filename):
        """
        提交文件到百度云查杀
        @filename 本地文件
        """
        try:
            if os.path.exists(filename):  
                if self.webshellchop(filename):return True

                data = public.ExecShell('curl https://scanner.baidu.com/enqueue -F archive=@%s' % filename)
                data = json.loads(data[0])
                
                time.sleep(5)
                import http_requests
                default_headers = { 'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36' }
                data_list = http_requests.get(url=data['url'], headers=default_headers, verify=False)
                data2 = data_list.json()
                if 'data' in data2[0]:

                    if len(data2[0]['data']) >= 1:
                        if 'descr' in data2[0]['data'][0]:
                            if 'WebShell' in data2[0]['data'][0]['descr']:
                                print('%s文件为木马'%filename)
                                self.send_baota(filename)
                                return True
                return False
            else:
                return False
        except:
            return False

    def read_file_md5(self, filename):
        """
        读取文件md5
        @filename 本地文件列表
        """
        if os.path.exists(filename):
            with open(filename, 'rb') as fp:
                data = fp.read()
            file_md5 = hashlib.md5(data).hexdigest()
            return file_md5
        else:
            return False

    def send_baota(self, filename):
        """
        提交到云查杀
        @filename 本地文件路径
        """
        cloudUrl = 'http://www.bt.cn/api/panel/btwaf_submit'
        pdata = {'codetxt': public.ReadFile(filename), 'md5': self.read_file_md5(filename), 'type': '0',
                 'host_ip': public.GetLocalIp(), 'size': os.path.getsize(filename)}
        ret = public.httpPost(cloudUrl, pdata)
        return True

    def check_webshell(self, filename):
        """
        宝塔云查杀接口
        @filename 本地文件路径
        """
        if not os.path.exists(filename): return False
        cloudUrl = 'http://www.bt.cn/api/panel/btwaf_check_file'
        pdata = {'md5': self.read_file_md5(filename), 'size': os.path.getsize(filename)}
        ret = public.httpPost(cloudUrl, pdata)
        if ret == '0':
            return False
        elif ret == '1':
            return False
        elif ret == '-1':
            return False
        else:
            return False

    def __get_md5(self, s):
        m = hashlib.md5()
        m.update(s.encode('utf-8'))
        return m.hexdigest()

if __name__ == "__main__":
        
    type=sys.argv[1]
    path=sys.argv[2]
    send=sys.argv[3]
    
    web_check = webshell_check()
    if type=='dir':
        data = web_check.san_dir(path,send)   
    elif type=='site':
        data = web_check.san_site(path,send)

