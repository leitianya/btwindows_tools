#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板 
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 沐落 <cjx@bt.cn>
# +-------------------------------------------------------------------

#--------------------------------
# 宝塔公共库
#--------------------------------

import json,os,sys,time,re,win32service,winreg,psutil,xmltodict,psutil,socket,base64
import win32net,win32netcon,win32security,win32netcon
import win32serviceutil as service
from xml.dom import minidom

file_read = 1179785
file_exec = 1179817
file_modify = 1245631
file_all = 2032127

server_err = None

def M(table):

    """
        @name 访问面板数据库
        @table 被访问的表名(必需)
        @return db.Sql object
        ps: 默认访问data/default.db
    """
    import db
    sql = db.Sql()
    return sql.table(table);

def http_get_home(url,timeout,ex):
    """
        @name Get方式使用优选节点访问官网
        @param url 当前官网URL地址
        @param timeout 用于测试超时时间
        @param ex 上一次错误的响应内容
        @return string 响应内容

        如果已经是优选节点，将直接返回ex
    """
    try:
        home = 'www.bt.cn'
        if url.find(home) == -1: return ex
        hosts_file = "config/hosts.json"
        if not os.path.exists(hosts_file): return ex
        hosts = json.loads(readFile(hosts_file))
        headers = {"host":home}
        for host in hosts:
            new_url = url.replace(home,host)
            res = HttpGet(new_url,timeout,headers)
            if res: 
                writeFile("data/home_host.pl",host)
                set_home_host(host)
                return res
        return ex
    except: return ex


def set_home_host(host):
    pass

def HttpGet(url,timeout = 60,headers = {}):
    """
    发送GET请求
    @url 被请求的URL地址(必需)
    @timeout 超时时间默认60秒
    return string
    """  
    home = 'www.bt.cn'
    host_home = 'data/home_host.pl'
    old_url = url
    if url.find(home) != -1:
        if os.path.exists(host_home): 
            headers['host'] = home
            url = url.replace(home,readFile(host_home))
    try:
        import urllib.request,ssl
        try:
            ssl._create_default_https_context = ssl._create_unverified_context
        except:pass;
        req = urllib.request.Request(url,headers = headers)
        response = urllib.request.urlopen(req,timeout = timeout)
        result = response.read()
        if type(result) == bytes: 
            try:
                result = result.decode('utf-8')
            except :
                result = result.decode('gb2312')            
        return result
    except Exception as ex:
        if old_url.find(home) != -1: return http_get_home(old_url,timeout,str(ex))
        if headers: return False
        return str(ex)

def httpGet(url,timeout=60):
    return HttpGet(url,timeout)

def HttpPost(url,data,timeout = 60,headers = {}):
    """
    发送POST请求
    @url 被请求的URL地址(必需)
    @data POST参数，可以是字符串或字典(必需)
    @timeout 超时时间默认60秒
    return string
    """
    start = time.time();
    home = 'www.bt.cn'
    host_home = 'data/home_host.pl'
    old_url = url
    if url.find(home) != -1:
        if os.path.exists(host_home): 
            headers['host'] = home
            url = url.replace(home,readFile(host_home))
    try:
        import urllib.request,ssl
        try:
            ssl._create_default_https_context = ssl._create_unverified_context
        except:pass;
        data2 = urllib.parse.urlencode(data).encode('utf-8')
        req = urllib.request.Request(url, data2,headers = headers)
        response = urllib.request.urlopen(req,timeout = timeout)
        result = response.read()
        if type(result) == bytes: result = result.decode('utf-8')
        #print(url,time.time() - start)
        return result
    except Exception as ex:
        if old_url.find(home) != -1: return http_post_home(old_url,data,timeout,str(ex))
        if headers: return False
        return str(ex);

def httpPost(url,data,timeout = 20):
    if timeout < 5: timeout = 5
    return HttpPost(url,data,timeout)


def http_post_home(url,data,timeout,ex):
    """
        @name POST方式使用优选节点访问官网
        @param url(string) 当前官网URL地址
        @param data(dict) POST数据
        @param timeout(int) 用于测试超时时间
        @param ex(string) 上一次错误的响应内容
        @return string 响应内容

        如果已经是优选节点，将直接返回ex
    """
    try:
        home = 'www.bt.cn'
        if url.find(home) == -1: return ex
        hosts_file = "config/hosts.json"
        if not os.path.exists(hosts_file): return ex
        hosts = json.loads(readFile(hosts_file))
        headers = {"host":home}
        for host in hosts:
            new_url = url.replace(home,host)
            res = HttpPost(new_url,data,timeout,headers)
            if res: 
                writeFile("data/home_host.pl",host)
                set_home_host(host)
                return res
        return ex
    except: return ex

def Md5(strings):
    """
    生成MD5
    @strings 要被处理的字符串
    return string(32)
    """
    import hashlib
    m = hashlib.md5()
 
    m.update(strings.encode('utf-8'))
    return m.hexdigest()

def md5(strings):
    return Md5(strings)

def FileMd5(filename):
    """
    生成文件的MD5
    @filename 文件名
    return string(32) or False
    """
    if not os.path.isfile(filename): return False;
    import hashlib;
    my_hash = hashlib.md5()
    f = open(filename,'rb')
    while True:
        b = f.read(8096)
        if not b :
            break
        my_hash.update(b)
    f.close()
    return my_hash.hexdigest();


def GetRandomString(length):
    """
       取随机字符串
       @length 要获取的长度
       return string(length)
    """
    from random import Random
    strings = ''
    chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz0123456789'
    chrlen = len(chars) - 1
    random = Random()
    for i in range(length):
        strings += chars[random.randint(0, chrlen)]
    return strings

def GetRandomString1(length):
    """
       取随机数字
       @length 要获取的长度 
       return string(length)
    """

    from random import Random
    strings = ''
    chars = '0123456789'
    chrlen = len(chars) - 1
    random = Random()
    for i in range(length):
        strings += chars[random.randint(0, chrlen)]
    return strings

def GetRandomString2(length):
    """
       取随机特殊字符串
       @length 要获取的长度
       return string(length)
    """

    from random import Random
    strings = ''
    chars = '!@#$%^&*()_+.,?[]-='
    chrlen = len(chars) - 1
    random = Random()
    for i in range(length):
        strings += chars[random.randint(0, chrlen)]
    return strings

def bt_print(msg):
    """
       处理非utf8字符print输出             
       return 无
    """
    try:
        print(msg)
    except :
        try:
            print(msg,msg.encode('utf-8'))
        except :
            pass

def get_system_lang():
    ret = ExecShell('chcp')[0]
    tmp = re.search('(\d+)',ret)
    if tmp:
        return int(tmp.group(1))
    return 936

def ReturnJson(status,msg,args=()):
    """
    取通用Json返回
    @status  返回状态
    @msg  返回消息
    return string(json)
    """
    return GetJson(ReturnMsg(status,msg,args));

def returnJson(status,msg,args=()):
    return ReturnJson(status,msg,args)

def ReturnMsg(status,msg,args = ()):
    """
        @name 取通用dict返回
        @param status  返回状态
        @param msg  返回消息
        @return dict  {"status":bool,"msg":string}
    """
    log_message = json.loads(ReadFile('BTPanel/static/language/' + GetLanguage() + '/public.json'));
    keys = log_message.keys();
    if type(msg) == str:
        if msg in keys:
            msg = log_message[msg];
            for i in range(len(args)):
                rep = '{'+str(i+1)+'}'
                msg = msg.replace(rep,args[i]);
    return {'status':status,'msg':msg }

def returnMsg(status,msg,args = ()):
    return ReturnMsg(status,msg,args)


def GetJson(data):
    """
    将对象转换为JSON
    @data 被转换的对象(dict/list/str/int...)
    """
    from json import dumps
    if data == bytes: data = data.decode('utf-8')
    try:
        return dumps(data,ensure_ascii=False)
    except:
        return dumps(returnMsg(False,"错误的响应: %s" % str(data)))

def getJson(data):
    return GetJson(data)

def get_str_code(f_body):
    from chardet.universaldetector import UniversalDetector
    detector = UniversalDetector()
    detector.feed(f_body)
    detector.close()
    char = detector.result
    return char;


def decode_data(srcBody):
    """
    遍历解码字符串
    """
    arrs = ['utf-8','GBK','ANSI','BIG5']
    for encoding in arrs:
        try:
             data = srcBody.decode(encoding)
             return encoding,data
        except:pass
    return False,None

def ReadFile(filename,mode = 'r'):
    """
    读取文件内容
    @filename 文件名
    return string(bin) 若文件不存在，则返回None
    """

    import os,chardet
    if not os.path.exists(filename): return False
    if not os.path.isfile(filename): return False

    encoding = 'utf-8'
    f_body = '';
    try:
        fp = open(filename, mode,encoding = encoding)
        f_body = fp.read()
    except :
        try:
            fp.close()
        except :pass

        try:
            encoding = 'gbk'
            fp = open(filename, mode,encoding = encoding)
            f_body = fp.read()
        except :
            try:
                fp.close()
            except :pass

            encoding = 'ansi'
            fp = open(filename, mode,encoding = encoding)
            f_body = fp.read()
    
    try:
        if f_body[0] == '\ufeff':            
            #处理带bom格式
            new_code = chardet.detect(f_body.encode(encoding))["encoding"]
            f_body = f_body.encode(encoding).decode(new_code);
    except : pass    
    
    fp.close()   
    return f_body


def readFile(filename,mode='r'):
    return ReadFile(filename,mode)


def readFile2(filename,mode='r'):
    """
    读取文件二进制文件
    @filename 文件名
    @return bin 返回二进制文件
    """
    import os
    if not os.path.exists(filename): return False
    if not os.path.isfile(filename): return False

    fp = open(filename, mode)
    f_body = fp.read()
    fp.close()   
    return f_body

def WriteFile(filename,s_body,mode='w+',encoding = 'utf-8'):
    """
    写入文件内容
    @filename 文件名
    @s_body 欲写入的内容
    return bool 若文件不存在则尝试自动创建
    """
    try:
        fp = open(filename, mode,encoding = encoding);
        fp.write(s_body)
        fp.close()
        return True
    except:
        return False

def writeFile(filename,s_body,mode='w+',encoding = 'utf-8'):
    return WriteFile(filename,s_body,mode,encoding)

def writeFile2(filename,s_body,mode='w+'):
    """
    写入字节文件内容
    @filename 文件名
    @s_body 欲写入的内容
    
    """
    try:
        fp = open(filename, mode);
        fp.write(s_body)
        fp.close()
        return True
    except:
        return False

def WriteLog(type,logMsg,args=()):
    """
    报错操作日志
    @type 操作日志类型
    @logMsg 日志内容
    @args 日志内容中的参数
    """
    #写日志
    #try:

    

    uid = 1
    username = 'system'
    try:
        from BTPanel import session
        if 'username' in session:
            username = session['username']
            uid = session['uid']
            if session.get('debug') == 1: return
    except:
        pass

    import time,db,json
    logMessage = json.loads(readFile('BTPanel/static/language/' + get_language() + '/log.json'));
    keys = logMessage.keys();
    if logMsg in keys:
        logMsg = logMessage[logMsg];
        for i in range(len(args)):
            rep = '{'+str(i+1)+'}'
            logMsg = logMsg.replace(rep,args[i]);
    if type in keys: type = logMessage[type];
    sql = db.Sql()
    mDate = time.strftime('%Y-%m-%d %X',time.localtime());
    data = (uid,username,type,logMsg,mDate);
    result = sql.table('logs').add('uid,username,type,log,addtime',data);
    #except:
        #pass

def GetLanguage():
    '''
    取语言
    '''
    return GetConfigValue("language")

def get_language():
    return GetLanguage()

def GetConfigValue(key):
    '''
    取配置值
    @key 配置项的key
    '''
    config = GetConfig()
    if not key in config.keys(): return None
    return config[key]

def SetConfigValue(key,value):
    """
    设置面板配置
    @key 配置项的key
    @value 配置项的值
    """
    config = GetConfig()
    config[key] = value
    WriteConfig(config)

def GetConfig():
    '''
    取所有配置项
    return json格式
    '''
    path = "config/config.json"
    if not os.path.exists(path): return {}
    f_body = ReadFile(path)
    if not f_body: return {}
    return json.loads(f_body)

def WriteConfig(config):
    """
    保存所有配置
    @config json格式配置文件
    """
    path = "config/config.json"
    WriteFile(path,json.dumps(config))


def GetLan(key):
    """
    取提示消息
    """
    log_message = json.loads(ReadFile('BTPanel/static/language/' + GetLanguage() + '/template.json'));
    keys = log_message.keys();
    msg = None;
    if key in keys:
        msg = log_message[key];
    return msg;

def getLan(key):
    return GetLan(key)

def GetMsg(key,args = ()):
    """
    根据key获取内置消息返回
    @key 指定消息的key
    @args 消息内容中的参数
    """
    try: 
        log_message = json.loads(ReadFile('BTPanel/static/language/' + GetLanguage() + '/public.json'));        
        keys = log_message.keys();
        msg = None;
        if key in keys:
            msg = log_message[key];
            for i in range(len(args)):
                rep = '{'+str(i+1)+'}'
                msg = msg.replace(rep,args[i]);
        return msg;
    except:
        return key

def getMsg(key,args = ()):
    return GetMsg(key,args)

def get_error_info():
    """
    获取面板详细错误
    """
    import traceback
    errorMsg = traceback.format_exc();
    return errorMsg


def kill(name,username = None):
    """
    结束指定进程
    @name 进程名
    @username 按进程和运行用户结束
    """
    shell = "taskkill /f /t /im %s" % name
    if username:
        shell = 'taskkill /f /t /fi "username eq %s" /im %s ' % (username,name)
    os.system(shell);

def GetWebServer():
    """
    获取Web服务器
    """
    webserver = None;
    if get_server_status('nginx') >= 0:
        webserver = 'nginx'
    elif get_server_status('apache') >= 0:
        webserver = 'apache';
    else:
        if os.path.exists('data/iis.setup'): webserver = 'iis'
   
    return webserver;

def get_webserver():
    return GetWebServer()

def get_ppids(pid,name,ppids = []):
    """
    获取进程ppid
    """
    proc = psutil.Process(pid)
    if proc.name() == name:
        if not proc.pid in ppids: ppids.append(proc.pid)        
        get_ppids(proc.ppid(),name,ppids)
    return True

def ServiceReload(siteName = None):
    """
    重载Web服务配置
    @siteName 网站名称，IIS专用，重启指定IIS网站    
    """
    webserver = get_webserver()
    result = '';
    if webserver == 'nginx':
        set_server_status("nginx","stop")   
        set_server_status("nginx","start") 
    elif webserver == 'apache':        
        ser = psutil.win_service_get(webserver)
        if ser:
            os.system('taskkill /pid {} -t -f'.format(ser.pid()))
            time.sleep(0.2);

        os.system('net start apache')
    else:        
        if siteName:
            appcmd = "C:\\windows\\system32\\inetsrv\\appcmd.exe"
            ExecShell(appcmd + ' stop apppool /apppool.name:"%s"' % (siteName))
          
            ExecShell(appcmd + ' start apppool /apppool.name:"%s"' % (siteName))
        else:
            result = ExecShell('iisreset')
    return result;

def serviceReload(siteName = None):
    return ServiceReload(siteName)

def clear_chcp(msg):
    """
    清除活动代码
    """
    msg = re.sub('Active code page: \d+','',msg)
    return msg


def ExecProcess(path,fio = None, env = None):
    """
    进程通信
    @env 环境变量
    @data post参数 id=123&name=admin
    @path 进程路径
    """
    import subprocess
    sub = subprocess.Popen(path, env = env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)       
    if not sub: return None,None   
    
    if fio:
        buff_size = 1024
        while True:
            tip_data = fio.read(buff_size)
            if not tip_data:break
            sub.stdin.write(tip_data)
    return sub.stdout


def ExecShell(cmdstring, cwd=None, timeout=None, shell=True,output = False):
    """
    通过管道执行SHELL
    @cmdstring 需要执行的cmd命令
    @cwd 设置工作目录
    @timeout 超时时间
    @shell 是否通过shell输出
    @output 是否通过文件重定向输出结果（当结果数据量过大必须使用此参数，否则造成管道阻塞）
    """
    import shlex
    import datetime
    import subprocess
    import time,tempfile

    if output: 
        ExecShell("del /s {}\panel\data\*.clog".format(to_path(GetConfigValue('setup_path'))))
        cmd_name = GetRandomString(8)
        sucess_path = 'data/{}_sucess.clog'.format(cmd_name)
        error_path = 'data/{}_error.clog'.format(cmd_name)

        shell = '{} 1>{} 2>{}'.format(cmdstring,sucess_path,error_path)
        os.system(shell)
        time.sleep(0.1)
        sucess = ''
        error = ''
        if os.path.exists(sucess_path): sucess = readFile(sucess_path)
        if os.path.exists(error_path): error = readFile(error_path)

        return clear_chcp(sucess),error
    else:
        a = ''
        e = ''
        try:
            rx = md5(cmdstring)
            succ_f = tempfile.SpooledTemporaryFile(max_size = 4096000,mode = 'wb+',suffix = '_succ',prefix='btex_' + rx ,dir='data')
            err_f = tempfile.SpooledTemporaryFile(max_size = 4096000,mode = 'wb+',suffix = '_err',prefix='btex_' + rx ,dir='data')

            sub = subprocess.Popen(cmdstring, shell=shell,bufsize=128,stdout=succ_f,stderr=err_f)
            sub.wait()

            err_f.seek(0)
            succ_f.seek(0)
            a = succ_f.read()
            e = err_f.read()

            if not err_f.closed: err_f.close()
            if not succ_f.closed: succ_f.close()
        except:
            print(get_error_info())

        if type(a) == bytes: 
            try:
                a = a.decode('utf-8')
            except : 
                try:
                    a = a.decode('utf-16')
                except :
                    a = a.decode('gb2312','ignore')
                    
        if type(e) == bytes: 
            try:
                e = e.decode('utf-8')
            except :
                try:
                   a = a.decode('utf-16')
                except :
                   e = e.decode('gb2312','ignore')
        return a,e
    

def ExecPowerShell(cmdstring, cwd=None, timeout=None, shell=True):
    """
    通过管道执行PowerShell
    @cmdstring 需要执行的cmd命令
    @cwd 设置工作目录
    @timeout 超时时间
    @shell 是否通过shell输出
    """

    try:
        #通过管道执行SHELL
        import shlex
        import datetime
        import subprocess
        import time

        if shell:
            cmdstring_list = cmdstring
        else:
            cmdstring_list = shlex.split(cmdstring)
    
        if timeout:
            end_time = datetime.datetime.now() + datetime.timedelta(seconds=timeout)
    
        sub = subprocess.Popen(cmdstring_list, cwd=cwd, shell=shell,bufsize=4096,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    
        while sub.poll() is None:
            time.sleep(0.1)
            if timeout:
                if end_time <= datetime.datetime.now():
                    raise Exception("Timeout：%s"%cmdstring)
        a,e = sub.communicate()
        if type(a) == bytes: a = a.decode('gb2312')
        if type(e) == bytes: e = e.decode('gb2312')
    except :
        if not a:
            e = ''
            a = os.popen(cmdstring).read()
    return a,e

def GetLocalIp():
    """
    取本地外网IP

    """
    try:
        filename = os.getenv('BT_PANEL') + '/data/iplist.txt'
        ipaddress = readFile(filename)
        if not ipaddress:
           
            url = 'http://pv.sohu.com/cityjson?ie=utf-8'
            str = httpGet(url)
            ipaddress = re.search('\d+.\d+.\d+.\d+',str).group(0)
            WriteFile(filename,ipaddress)
        
        ipaddress = re.search('\d+.\d+.\d+.\d+',ipaddress).group(0);
        return ipaddress
    except:
        try:
            url =  'http://www.bt.cn/Api/getIpAddress';
            str = httpGet(url)
            return str
        except:
            return GetHost();

def GetHost(port = False):
    """
    获取面板当前访问的Host
    @port 面板端口
    """
    from flask import request
    host_tmp = request.headers.get('host')
    if not host_tmp: 
        if request.url_root:
            tmp = re.findall("(https|http)://([\w:\.-]+)",request.url_root)
            if tmp: host_tmp = tmp[0][1]
    if not host_tmp:
        host_tmp = GetLocalIp() + ':' + readFile('data/port.pl').strip()
    try:
        if host_tmp.find(':') == -1: host_tmp += ':80';
    except:
        host_tmp = "127.0.0.1:8888"
    h = host_tmp.split(':')
    if port: return h[1]
    return h[0]

def GetClientIp():
    from flask import request
    return request.remote_addr.replace('::ffff:','')

def phpReload(version):
    #重载PHP配置
    serviceReload()

def mod_reload(mode):
    """
    重载指定模块
    @mode 模块对象
    """
    if not mode: return False
    try:
        if sys.version_info[0] == 2:
            reload(mode)
        else:
            import imp
            imp.reload(mode)
        return True
    except: return False



def checkInput(data):
    """
    过滤字符串输入
    @data 输入的字符串
    """
    if not data: return data;
    if type(data) != str: return data;
    checkList = [
                {'d':'<','r':'＜'},
                {'d':'>','r':'＞'},
                {'d':'\'','r':'‘'},
                {'d':'"','r':'“'},
                {'d':'&','r':'＆'},
                {'d':'#','r':'＃'},
                {'d':'<','r':'＜'}
                ]
    for v in checkList:
        data = data.replace(v['d'],v['r']);
    return data;

#取文件指定尾行数
def GetNumLines(path,num,p=1):
    pyVersion = sys.version_info[0]
    max_len = 1024*128
    try:
        from html import escape
        if not os.path.exists(path): return ""
        start_line = (p - 1) * num
        count = start_line + num
        fp = open(path,'r')
        buf = ""
        fp.seek(-1, 2)
        if fp.read(1) == "\n": fp.seek(-1, 2)
        data = []
        total_len = 0
        b = True
        n = 0
        for i in range(count):
            while True:
                newline_pos = str.rfind(str(buf), "\n")
                pos = fp.tell()
                if newline_pos != -1:
                    if n >= start_line:
                        line = buf[newline_pos + 1:]
                        line_len = len(line)
                        total_len += line_len
                        sp_len = total_len - max_len
                        if sp_len > 0:
                            line = line[sp_len:]
                        try:
                            data.insert(0,escape(line))
                        except: pass
                    buf = buf[:newline_pos]
                    n += 1
                    break
                else:
                    if pos == 0:
                        b = False
                        break
                    to_read = min(4096, pos)
                    fp.seek(-to_read, 1)
                    t_buf = fp.read(to_read)
                    if pyVersion == 3:
                        try:
                            if type(t_buf) == bytes: t_buf = t_buf.decode('utf-8')
                        except:
                            try:
                                if type(t_buf) == bytes: t_buf = t_buf.decode('gbk')
                            except :
                                t_buf = str(t_buf)
                    buf = t_buf + buf
                    fp.seek(-to_read, 1)
                    if pos - to_read == 0:
                        buf = "\n" + buf
                if total_len >= max_len: break
            if not b: break
        fp.close()
        result = "\n".join(data)
        if not result: raise Exception('null')
    except:
        result = ExecShell("tail -n {} {}".format(num,path))[0]
        if len(result) > max_len:
            result = result[-max_len:]

    try:
        try:
            result = json.dumps(result)
            return json.loads(result).strip()
        except:
            if pyVersion == 2:
                result = result.decode('utf8',errors='ignore')
            else:
                result = result.encode('utf-8',errors='ignore').decode("utf-8",errors="ignore")
        return result.strip()
    except: return ""

def GetNumLines(path,num,p=1):
    """
    取文件指定尾行数
    @path 文件路径
    @num 每次取多少行
    @p 倒数第几页
    """
    pyVersion = sys.version_info[0]
    data = []
    try:
        from html import escape
        if not os.path.exists(path): return "";
        start_line = (p - 1) * num;
        count = start_line + num;
        fp = open(path,'rb')
        buf = ""
        fp.seek(-1, 2)
        if fp.read(1) == "\n": fp.seek(-1, 2)
       
        b = True
        n = 0;
        for i in range(count):
            while True:
                newline_pos = str.rfind(str(buf), "\n")
                pos = fp.tell()
                if newline_pos != -1:
                    if n >= start_line:
                        line = buf[newline_pos + 1:]
                        try:
                            n_line = escape(line,quote=False)
                            data.insert(0,n_line)
                        except: 
                            try:
                                data.insert(0,n_line)
                            except:pass
                    buf = buf[:newline_pos]
                    n += 1;
                    break;
                else:
                    if pos == 0:
                        b = False
                        break
                    to_read = min(4096, pos)
                    fp.seek(-to_read, 1)
                    t_buf = fp.read(to_read)
                    if pyVersion == 3:
                        try:
                            if type(t_buf) == bytes: t_buf = t_buf.decode('utf-8')
                        except:
                            try:
                                if type(t_buf) == bytes: t_buf = t_buf.decode('gbk')
                            except :                                
                                t_buf = ''
                    buf = t_buf + buf
                    fp.seek(-to_read, 1)
                    if pos - to_read == 0:
                        buf = "\n" + buf
            if not b: break;
        fp.close()
    except:
        if os.path.getsize(path) == 0: return '';
        return ExecShell("tail -n {} {}".format(num,path))[0]
    return "\n".join(data)

def getPanelAddr():
    """
    获取面板地址
    """
    from flask import request
    protocol = 'https://' if os.path.exists("data/ssl.pl") else 'http://'
    return protocol + request.headers.get('host')

def format_date(format="%Y-%m-%d %H:%M:%S",times = None):
    """
    格式化指定时间戳
    @format 时间格式
    @times 时间戳
    return 字符串时间格式
    """
    if not times: times = int(time.time())
    time_local = time.localtime(times)
    return time.strftime(format, time_local) 

def to_size(size):
    """
    字节单位转换
    @size 字节大小
    return 返回带单位的格式(如：1 GB)
    """
    if not size: return '0.00 b'
    size = float(size)

    d = ('b','KB','MB','GB','TB');
    s = d[0];
    for b in d:
        if size < 1024: return ("%.2f" % size) + ' ' + b;
        size = size / 1024;
        s = b;
    return ("%.2f" % size) + ' ' + b;

def get_size(size):
    """
    字节单位转换
    @size 字节大小
    return 返回带单位的格式(如：1 G)
    """
    d = ('b','K','M','G','T');
    s = d[0];
    for b in d:
        if size < 1024: return str(round(size,2)) + ' ' + b;
        size = size / 1024;
        s = b;
    return str(round(size,2)) + ' ' + b;

def checkCode(code,outime = 120):
    """
    校验验证码
    @code 验证码
    @outime 超时时间
    """
    
    from BTPanel import session,cache
    try:
        codeStr = cache.get('codeStr')
        cache.delete('codeStr')
        if not codeStr:
            session['login_error'] = GetMsg('CODE_TIMEOUT')
            return False

        if md5(code.lower()) != codeStr:
            session['login_error'] = GetMsg('CODE_ERR')
            return False
        return True
    except:
        session['login_error'] = GetMsg('CODE_NOT_EXISTS')
        return False

def writeSpeed(title,used,total,speed = 0):
    """
    设置事件进度
    @title 事件标题
    @used 已完成进度
    @total 总进度
    @speed 速度
    """
    import json
    if not title:
        data = {'title':None,'progress':0,'total':0,'used':0,'speed':0}
    else:
        progress = int((100.0 * used / total));
        data = {'title':title,'progress':progress,'total':total,'used':used,'speed':speed}
    writeFile('data/panelSpeed.pl',json.dumps(data));
    return True;


def getSpeed():
    """
    取事件进度

    """
    import json;
    data = readFile('data/panelSpeed.pl');
    if not data: 
        data = json.dumps({'title':None,'progress':0,'total':0,'used':0,'speed':0})
        writeFile('data/panelSpeed.pl',data);
    return json.loads(data);


def downloadFileByWget(url,filename):
    """
    wget下载文件
    @url 下载地址
    @filename 本地文件路径
    @说明： 部分系统
    """
    loacl_path =  '{}/script/wget.exe'.format(os.getenv('BT_PANEL'))
    if not os.path.exists(loacl_path):
        downloadFile(get_url()+'/win/panel/data/wget.exe',loacl_path)   
    shell = "{} {} -O {} -t 5 -T 60".format(loacl_path,url,filename)
    os.system(shell)

    num = 0
    re_size = 0
    while num <= 20:
        if os.path.exists(filename):
            cr_size = os.path.getsize(filename)
            if re_size > 0 and re_size == cr_size:
                break;
            else:
                re_size = cr_size
        time.sleep(0.5)  
        num += 1

    if os.path.exists(filename):            
        if os.path.getsize(filename) < 1:
            os.remove(filename)
            downloadFile(url,filename)
        else:
            downloadFile(url,filename)

def downloadFile(url,filename): 
    """
    下载文件
    @url 下载地址
    @filename 本地文件路径
    说明：重试3次，http尝试下载2次，失败尝试用wget下载一次
    """
    try:
        bt_print('准备下载文件[' + os.path.basename(filename) + ']')  
        import urllib.request
        urllib.request.urlretrieve(url,filename=filename ,reporthook= downloadHook)
    except Exception as ex:
        nUrl = url;
        download = url
        try:
            import re
            tmp = re.match('(.+)(/win/.+)',url)
            if tmp: 
                bt_print("节点[%s]连接失败，无法下载文件[%s]" % (tmp.groups()[0],url))
                download = get_url(0.5)
                nUrl = url.replace(tmp.groups()[0],download)
            else:
                home = 'www.bt.cn'
                host_home = 'data/home_host.pl'      
                if url.find(home) != -1:
                    if os.path.exists(host_home): 
                        download = readFile(host_home)                       
                        nUrl = url.replace(home,download)
                
            bt_print('重新选择下载节点[%s]，准备下载文件[%s]' % (download,os.path.basename(filename)))  
               
            import urllib.request
            urllib.request.urlretrieve(nUrl,filename=filename ,reporthook= downloadHook)
        except Exception as e :
            try:
                time.sleep(0.5)
                downloadFileByWget(url,filename)
            except Exception as exx :                
                err_info = '节点1：无法下载[%s] 错误详情->> %s \r\n 节点2： 无法下载文件[%s] 错误详情->> %s' %(url,str(ex),nUrl,str(exx))    
                submit_panel_bug(err_info) 

def downloadHook(count, blockSize, totalSize):
    """
    下载回调
    @count 
    @totalSize 总大小
    @blockSize 未完成大小
    """
    speed = {'total':totalSize,'block':blockSize,'count':count}
    rate = int(100.0 * count * blockSize / totalSize)
    if rate > 100: rate = 100
    bt_print(to_size(count * blockSize) + '.......... .......... .......... ..........' + str(rate) + '%')



def inArray(arrays,searchStr):
    """
    搜索数据中是否存在
    @arrays 数组列表
    @searchStr 查找字符串
    """
    for key in arrays:
        if key == searchStr: return True
    
    return False

#
def checkWebConfig():
    """
    检查Web服务器配置文件是否有错误
    """
    serverType = get_webserver()
    if serverType == 'nginx':
        shell = "%s && cd %s/nginx && nginx.exe -t" % (os.getenv("BT_SETUP")[0:2],os.getenv("BT_SETUP"))
        result = ExecShell(shell);
        print(result)
        searchStr = 'successful'
    elif serverType == 'apache':
        shell = os.getenv("BT_SETUP") + '/apache/bin/httpd.exe -t'
        result = ExecShell(shell);
        searchStr = 'Syntax OK'
    else:
        return True
    if result[1].find(searchStr) == -1:
        WriteLog("TYPE_SOFT", 'CONF_CHECK_ERR',(result[1].replace('\\','/'),));
        return result[1];
    return True;



def checkIp(ip):
    """
    检查是否为IPv4地址
    @ip ipv4地址
    """
    p = re.compile('^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$')  
    if p.match(ip):  
        return True  
    else:  
        return False
    

def checkPort(port):
    """
    检查端口是否合法
    @port 端口号
    """
    try:
        if not re.match('^\d+$',port):  return False
    
        ports = ['21','25','443','8080','888','8888','8443'];
        if port in ports: return False;
        intport = int(port);
        if intport < 1 or intport > 65535: return False;
        return True;
    except :
        return False;

def getStrBetween(startStr,endStr,srcStr):
    """
    字符串取中间
    @startStr 截取开始字符串
    @endStr 截取结束字符串
    @srcStr 源字符串
    """
    start = srcStr.find(startStr)
    if start == -1: return None
    end = srcStr.find(endStr)
    if end == -1: return None
    return srcStr[start+1:end]

def getCpuType():
    """
    取CPU类型
    """
    try:
        cpuType = ReadReg(r'HARDWARE\DESCRIPTION\System\CentralProcessor\0','ProcessorNameString')
    except :
        cpuType = ''    
    return cpuType;

def IsRestart():
    """
    检查是否允许重启
    """
    num  = M('tasks').where('status!=?',('1',)).count();
    if num > 0: return False;
    return True;

def hasPwd(password):
    """
    加密密码字符
    @password  密码
    """
    import crypt;
    return crypt.crypt(password,password);


def get_timeout(url,timeout=3):
    """
    获取url超时事件
    @url url地址
    @timeout 超时时间
    """
    try:
        start = time.time()
        result = int(httpGet(url,timeout))
        return result,int((time.time() - start) * 1000 - 500)
    except: return 0,False

def get_url(timeout = 0.5):
    """
    节点测速
    @timeout 超时时间
    """
    import json
    try:
        nodeFile = 'data/node.json'
        node_list = json.loads(readFile(nodeFile))
        mnode1 = []
        mnode2 = []
        mnode3 = []
        for node in node_list:
            node['net'],node['ping'] = get_timeout(node['protocol'] + node['address'] + ':' + node['port'] + '/net_test',1)
            if not node['ping']: continue
            if node['ping'] < 100:      #当响应时间<100ms且可用带宽大于1500KB时
                if node['net'] > 1500:
                    mnode1.append(node)
                elif node['net'] > 1000:
                    mnode3.append(node)
            else:
                if node['net'] > 1000:  #当响应时间>=100ms且可用带宽大于1000KB时
                    mnode2.append(node)
            if node['ping'] < 100:
                if node['net'] > 3000: break #有节点可用带宽大于3000时，不再检查其它节点
        if mnode1: #优选低延迟高带宽
            mnode = sorted(mnode1,key= lambda  x:x['net'],reverse=True)
        elif mnode3: #备选低延迟，中等带宽
            mnode = sorted(mnode3,key= lambda  x:x['net'],reverse=True)
        else: #终选中等延迟，中等带宽
            mnode = sorted(mnode2,key= lambda  x:x['ping'],reverse=False)

        print('                                                 ')
        print('Waiting for connection:' + node['address'] + ':' + node['port'])
        print('speed:{} ms ,idle : {}'.format(node['ping'],node['net']))
        print('-------------------------------------------------')

        if not mnode: return 'http://download.bt.cn'
        return mnode[0]['protocol'] + mnode[0]['address'] + ':' + mnode[0]['port']
    except:
        return 'http://download.bt.cn'

def getDate(format='%Y-%m-%d %X'):
    """
    取格式时间
    """
    return time.strftime(format,time.localtime())

def CheckPort(port,other=None):
    """
    检查端口是否合法
    @port 端口号（1-65535）
    @other 是否检测是面板使用的端口
    """
    if type(port) == str: port = int(port)
    if port < 1 or port > 65535: return False
    if other:
        checks = [22,20,21,8888,3306,11211,888,25]
        if port in checks: return False
    return True

#获取Token
def GetToken():
    try:
        tokenFile = 'data/token.json';
        if not os.path.exists(tokenFile): return False;
        token = json.loads(readFile(tokenFile));
        return token;
    except:
        return False


#解密数据
def auth_decode(data):
    token = GetToken()
    #是否有生成Token
    if not token: return returnMsg(False,'REQUEST_ERR')
    
    #校验access_key是否正确
    if token['access_key'] != data['btauth_key']: return returnMsg(False,'REQUEST_ERR')
    
    #解码数据
    import binascii,hashlib,urllib,hmac,json
    tdata = binascii.unhexlify(data['data']);
    
    #校验signature是否正确
    signature = binascii.hexlify(hmac.new(token['secret_key'], tdata, digestmod=hashlib.sha256).digest());
    if signature != data['signature']: return returnMsg(False,'REQUEST_ERR');
    
    #返回
    return json.loads(urllib.unquote(tdata));
    
def auth_encode(data):
    """
    数据加密
    @data 需要加密的数据
    """
    token = GetToken()
    pdata = {}
    
    #是否有生成Token
    if not token: return returnMsg(False,'REQUEST_ERR')
    
    #生成signature
    import binascii,hashlib,urllib,hmac,json
    tdata = urllib.quote(json.dumps(data));
    #公式  hex(hmac_sha256(data))
    pdata['signature'] = binascii.hexlify(hmac.new(token['secret_key'], tdata, digestmod=hashlib.sha256).digest());
    
    #加密数据
    pdata['btauth_key'] = token['access_key'];
    pdata['data'] = binascii.hexlify(tdata);
    pdata['timestamp'] = time.time()
    
    #返回
    return pdata;

def checkToken(get):
    """
    检查Token
    """
    tempFile = 'data/tempToken.json'
    if not os.path.exists(tempFile): return False
    import json,time
    tempToken = json.loads(readFile(tempFile))
    if time.time() > tempToken['timeout']: return False
    if get.token != tempToken['token']: return False
    return True;


def process_exists(pname,exe = None):
    """
    检查进程是否存在
    @pname 进程名称
    @exe 进程路径
    """
    try:
        pids = psutil.pids()
        for pid in pids:
            try:
                p = psutil.Process(pid)
                if p.name() == pname: 
                    if not exe:
                        return True;
                    else:
                        if p.exe() == exe: return True
            except:pass
        return False
    except: return True

def get_sys_version():
    """
    获取系统版本
    """
    import platform
    v = platform.version()
    arrs = v.split('.')
    arrs.append(v)
    return arrs

def restart_panel():
    """
    重启面板
    """
    import system
    return system.system().ReWeb(None)

def get_mac_address():
    """
    获取mac
    """
    import uuid
    mac=uuid.UUID(int = uuid.getnode()).hex[-12:]
    return ":".join([mac[e:e+2] for e in range(0,11,2)])


def to_string(lites):
    """
    字符串转码
    @lites 转码内容
    """
    if type(lites) != list: lites = [lites]
    m_str = ''
    for mu in lites:
        m_str += chr(mu)
    return m_str



def WriteReg(path,key,value,type = winreg.REG_SZ):
    """
    写入/创建注册表
    @path 注册表路径
    @key 注册表键值
    @value 注册表值
    @type 注册表值类型
    """
    import winreg
    try:
        newKey = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE ,path, 0 ,winreg.KEY_ALL_ACCESS)
    except :
        newKey = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE ,path)
    try:
        #SetValue 只支持字符串，其他类型使用SetValueEx
        if isinstance(value,int):
            winreg.SetValueEx(newKey,key,0,winreg.REG_DWORD,value)              
        else:           
            winreg.SetValueEx(newKey,key,0,type,value)
        return True
    except Exception as ex:
        print(str(ex),'error')
        return False

def ReadReg(path,key):
    """
    读取注册表
    @path 注册表路径
    @key 注册表键值
    """
    import winreg
    try:
        newKey = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE ,path)
        value,type = winreg.QueryValueEx(newKey, key)
        return value
    except :
        return False      

def DelReg(path,key):
    """
    删除注册表
    @path 注册表路径
    @key 注册表键值
    """
    import winreg
    try:
        newKey = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE ,path)
        winreg.DeleteKey(newKey,key)
        return True
    except :
        return False

def format_path(path):
    """
    格式化路径到后台
    @path 路径
    """
    return path.replace('\\','/')

def to_path(path):
    """
    格式化路径到前端
    @path 路径
    """
    return path.replace('/','\\')

def set_system_path(key,val):
    """
    设置系统环境变量
    @key 环境变量key
    @环境变量的值
    """
    ExecShell('setx /m '+ key +' "'+ val +'"')  
    if os.environ.get(key):
        return True
    return False

def create_server(name, disName, path, args = None, description = None,userName = None,password = None):
    """
    创建系统服务
    @name 服务名称
    @disName 显示名称
    @path exe文件路径
    @args 服务参数
    @description 服务描述
    @userName 启动用户
    @password 用户密码
    """
    try:
        import win32service
        if userName and userName.find('.\\') < 0:
            userName = '.\\{}'.format(userName)

        path = to_path(path)
        service.InstallService(name,name, disName,win32service.SERVICE_AUTO_START, errorControl = None, bRunInteractive = 0, serviceDeps = None, userName = userName, password = password, exeName = path, perfMonIni = None, perfMonDll = None, exeArgs = args, description = description , delayedstart = None)
        if get_server_status(name) > -1:
            set_server_status(name,'start')
            return True,''
        else:
            return False,''
    except :
        return False,get_error_info()

def change_server_start_type(name,type):
    """
    修改服务启动类型
    @name 服务名称
    @type 启动类型（1：自动 0：手动 -1：禁用）
    """
    try:
        startType = None
        if type == -1:
            startType = win32service.SERVICE_DISABLED
        elif type == 1:
            startType = win32service.SERVICE_AUTO_START
        else:
            startType = win32service.SERVICE_DEMAND_START

        scm = win32service.OpenSCManager(None, None,win32service.SC_MANAGER_ALL_ACCESS)
        if scm:
            svc = win32service.OpenService(scm, name,win32service.SC_MANAGER_ALL_ACCESS)
            if svc:
                win32service.ChangeServiceConfig(svc, win32service.SERVICE_NO_CHANGE,startType, win32service.SERVICE_NO_CHANGE, None, None, 0, None, None, None, None)
                return True,''
        return False,'无法打开服务管理器'
    except :
        return False,get_error_info()


def change_server_users(name,user = 'LocalSystem',password = None):
    """
    修改服务启动 用户
    @name 服务名称
    @user 启动用户（未设置代表管理员用户）
    @password 用户密码
    """
    try:
        if user and user.find('.\\') < 0:  user = '.\\{}'.format(user)

        import win32service
        scm = win32service.OpenSCManager(None, None,win32service.SC_MANAGER_ALL_ACCESS)
        if scm:
            svc = win32service.OpenService(scm, name,win32service.SC_MANAGER_ALL_ACCESS)
            if svc:
                win32service.ChangeServiceConfig(svc, win32service.SERVICE_NO_CHANGE,win32service.SERVICE_AUTO_START, win32service.SERVICE_NO_CHANGE, None, None, 0, None, user, password, None)
                return True

        return False,"无法打开服务管理器."
    except :
        return False,get_error_info()

def query_server_config(name):
    """
    查询服务配置
    @name 服务名称
    return 第1位：3（手动） 2（自动）
    """
    status = get_server_status(name)     
    if status > -1:        
        scm = win32service.OpenSCManager(None, None,win32service.SC_MANAGER_ALL_ACCESS)
        if scm:
            svc = win32service.OpenService(scm, name ,win32service.SC_MANAGER_ALL_ACCESS)
            if svc:
                config = win32service.QueryServiceConfig(svc)
                return config
    return None

def get_server_status(name):
    """
    获取服务状态 
    @name  服务名称
    return （-1：未安装 0：未启动 1：已启动）
    """
    try:
        serviceStatus = service.QueryServiceStatus(name)
        if serviceStatus[1] == 4:
            return 1
        return 0
    except :
        return -1


def start_service(name):
    """
    启动服务
    @name 服务名称
    return array（状态，错误详情）
    """
    error = None
    try:
        timeout = 0;
        while get_server_status(name) == 0:
            try:
                service.StartService(name)
                time.sleep(1);                        
            except : time.sleep(1);   
            timeout += 1
            
            otime = 180
            if name in ['apache','nginx']: otime = 300

            if timeout > otime:break

        if get_server_status(name) != 0:                
            return True,error
        return False,'操作失败，{}秒内未完成启动服务【{}】'.format(otime,name)
    except :
        return False,get_error_info()

def stop_service(name):
    """
    启动服务
    @name 服务名称
    return array（状态，错误详情）
    """
    error = None
    try:
        timeout = 0;
        while get_server_status(name) == 1:
            try:
                service.StopService(name)
                time.sleep(1);                        
            except : time.sleep(1);   
            timeout += 1

            otime = 180
            if name in ['apache','nginx']: otime = 300

            if timeout > otime:break

        if get_server_status(name) != 1:                
            return True,error
        return False,'操作失败，{}秒内未完成启动服务【{}】'.format(otime,name)
    except :
        return False,get_error_info()

def set_server_status(name,status):
    """
    设置服务状态
    @name 服务名称
    @status 服务状态（start）
    return array(状态，详情)
    """
    old_status = get_server_status(name)    
    if old_status > -1:
        try:
            if status == 'reload' or status == 'restart':                        
                ret,error = stop_service(name)
                if not ret: ret,error

                ret,error = start_service(name)
                if not ret: return ret,error

                return True,''
            else:
                if status == 'stop':
                    ret,error = stop_service(name)
                    if not ret: ret,error
                else:
                    ret,error = start_service(name)
                    if not ret: return ret,error
            return True,''
        except :           
            return False,get_error_info()
    return False,"{}服务未安装.".format(name)

def delete_server(name):
    """
    删除系统服务
    @name 服务名称
    return array(状态，详情)
    """
    try:
        stop_service(name)
        service.RemoveService(name)
        return True,''
    except :
        return False,get_error_info()

def get_server_path(name):
    """
    获取服务路径
    @name 服务名称
    return 服务路径
    """
    data = psutil.win_service_get(name).as_dict()
    path = data['binpath'].split(' ')[0].replace('"','')
    return path


def is_64bitos():
    """
    判断是否x64系统
    """
    import platform
    bites = {'AMD64':64, 'x86_64': 64, 'i386': 32, 'x86': 32}
    info = platform.uname()
    if bites.get(info.machine) == 64:
        return True
    return False

def get_appSetup(path,arrs):
    """
    批量查找软件是否安装
    @path 注册表路径
    @arrs 软件列表
    """
    key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,path)        
    countkey = winreg.QueryInfoKey(key)[0]
    for i in range(int(countkey)):
        try:
            oKey = winreg.EnumKey(key, i)          
            val = ReadReg(path + '\\' + oKey,'DisplayName')
            if not val: continue;            
            num = 0
            for name in arrs:
                if val.find(name) >= 0:
                    num += 1
                else:
                    num = 0;           
            if len(arrs) == num: return True;
        except :
            continue
    return False

def isAppSetup(arrs):   
    """
    根据多个内容匹配查找软件是否安装
    @arrs 软件名称列表
    """
    rRet = get_appSetup(r'SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',arrs)
    if not rRet:
        if is_64bitos(): rRet = get_appSetup(r'SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall',arrs)      
    return rRet

def get_vc_version(phpVersion):
    """
    根据php版本获取所需vc版本
    @phpVersion php版本
    return vc++版本
    """
    version = '2008';
    if phpVersion == '71' or phpVersion == '70':
        version = '2015'           
    elif phpVersion == '56' or phpVersion == '55':
        version = '2012'
    elif phpVersion == '72' or phpVersion == '73' or phpVersion == '74':
        version = '2015'
    return version

#检测vc版本
def check_setup_vc(phpVersion,bit = 'x86'):
    """
    根据php版本判断是否安装所需vc++
    @phpVersion php版本
    @bit 系统位数
    return bool 是否安装
    """
    #bit = ' x64' if is_64bitos() else ' x86'
    arrs = ['Visual C++',bit]
    if phpVersion == '71' or phpVersion == '70':
        arrs.append("2015")         
    elif phpVersion == '56' or phpVersion == '55':
        arrs.append("2012")
    elif phpVersion == '73' or phpVersion == '73' or phpVersion == '74':
        arrs.append("2015")
    elif phpVersion == '80':
        arrs.append("2019")
    else:
        arrs.append("2008")        
    return isAppSetup(arrs)

def setup_vc(version, bit = 'x86'):
   """
   安装vc++
   @version vc版本号
   @bit 系统位数
   """
   download_url = get_url()
   tmpPath = 'C:/temp'
   if not os.path.exists(tmpPath): os.makedirs(tmpPath)      
   temp = tmpPath + '/vc'+ version + '_' + bit + '.exe'  
   try:
        downloadFileByWget(download_url + '/win/vc/vcredist_'+ version +'_'+ bit +'.exe',temp)
   except :       
        downloadFile(download_url + '/win/vc/vcredist_'+ version +'_'+ bit +'.exe',temp)
   if not os.path.exists(temp): 
       return False
   ExecShell(temp + ' /q')
   return True


def loads_json(path):
    """
    从文件读取xml转为json对象
    @path 文件路径
    """
    data = {}
    try:
        conf = readFile(path)
        data = xmltodict.parse(conf)
    except :  pass
    return data


def dumps_json(conf):
    """
    json对象转为xml文件
    @conf json对象
    return str xml文件内容
    """
    xmlstr = xmltodict.unparse(conf)
    return xmlstr

def format_xml(conf):
    """
    格式化xml
    @conf 文件内容
    """
    b = minidom.parseString(conf)
    c = b.toprettyxml(indent = "\t")
    return c

def get_file_list(path, flist):     
    """
    递归获取目录所有文件列表
    @path 目录路径
    @flist 返回文件列表
    """
    if os.path.exists(path):        
        files = os.listdir(path)
        flist.append(path)
        for file in files:
            if os.path.isdir(path + '/' + file):
                get_file_list(path + '/' + file, flist)
            else:
                flist.append(path + '/' + file)

def get_paths(path,flist):
    """
    获取根目录列表
    @path 文件路径
    @flist 文件列表
    """
    try:
        path = path.replace('\\','/')
        path = os.path.dirname(path)
        if not path in flist:
            flist.append(path)
            get_paths(path,flist)
    except :
        pass



def SetFileAccess(filename,user,access):
    """
    设置文件权限(安装脚本使用)
    @filename 文件路径
    @user 用户名
    @access 用户权限
    """
    try:
        import win32security
        sd = win32security.GetFileSecurity(filename, win32security.DACL_SECURITY_INFORMATION)
        dacl = sd.GetSecurityDescriptorDacl()
        ace_count = dacl.GetAceCount()

        for i in range(ace_count, 0,-1):  
            try:
                data = {}
                data['rev'], data['access'], usersid = dacl.GetAce(i-1)
                data['user'],data['group'], data['type'] = win32security.LookupAccountSid('', usersid)                
                if data['user'].lower() == user.lower(): dacl.DeleteAce(i-1) #删除旧的dacl
            except :
                dacl.DeleteAce(i-1)
        try:
            userx, domain, type = win32security.LookupAccountName("", user)
        except :
            try:
                userx, domain, type = win32security.LookupAccountName("", 'IIS APPPOOL\\' + user)       
            except :
                return False,"【{}】用户不存在，无法设置权限。".format(user)
        if access > 0:  dacl.AddAccessAllowedAceEx(win32security.ACL_REVISION, 3, access, userx)
            
        sd.SetSecurityDescriptorDacl(1, dacl, 0)
        win32security.SetFileSecurity(filename, win32security.DACL_SECURITY_INFORMATION, sd)
        return True, None
    except :
        return False,get_error_info()


#设置文件权限和所有者（level:继承到子目录）
def set_file_access(filename,user,access,level = True):
    #是否继承
    if level:            
        if os.path.isdir(filename):
            filelist = []
            get_file_list(filename,filelist)
            for new_path in filelist: 
                status,info = SetFileAccess(new_path,user,access)
                if not status: return status,info 
            return True,None       
        else:
            return SetFileAccess(filename,user,access)
    else:
        return SetFileAccess(filename,user,access)

#删除文件权限
def del_file_access(filename,user):
    import win32security
    sd = win32security.GetFileSecurity(filename, win32security.DACL_SECURITY_INFORMATION)
    dacl = sd.GetSecurityDescriptorDacl()
    ace_count = dacl.GetAceCount()
        
    for i in range(ace_count ,0 ,-1):            
        try:
            data = {}
            data['rev'], data['access'], usersid = dacl.GetAce(i-1)
            data['user'],data['group'], data['type'] = win32security.LookupAccountSid('', usersid)   
            
            if data['user'].lower() == user.lower():      
                dacl.DeleteAce(i-1)
        except :            
            try:
                #处理拒绝访问
                dacl.DeleteAce(i-1)
            except : pass                
    sd.SetSecurityDescriptorDacl(1, dacl, 0)
    win32security.SetFileSecurity(filename, win32security.DACL_SECURITY_INFORMATION, sd)
    return True

def time_to_int(time):
    """
    时间转为int
    @time 时间格式 字符串
    return int N秒
    """
    if time.find('.') >=0 :
        d,t =  time.strip().split(".")        
    else:
        d = 0;
        t = time
    h,m,s = t.strip().split(":")
    return int(d) * 86400 + int(h) * 3600 + int(m) * 60 + int(s)


def int_to_time(seconds):
    """
    秒数转为具体天数
    @seconds 秒数
    return str 10:10
    """
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    d, h = divmod(h, 24)

    result = "%s.%02d:%02d:%02d" % (d,h, m, s)
    return result


def get_pip_list():
    """
    获取pip安装模块列表
    return list 
    """
    rRet = ExecShell(get_run_pip('[PIP] list'))
    list = rRet[0].split('\r\n')
    import re
    data = {}
    i = 0;
    for x in list:
        if i > 1:       
            temp = re.search('([\w-]+)\s+([\d\.]+)',x)
            if temp:
                key = temp.groups()[0]
                version = temp.groups()[1]
 
                item = {}
                item['version'] = version
                data[key] = item
        i += 1
    return data

def write_request_log():
    """
    写面板日志
    """
    
    try:
        from BTPanel import request,g,session
        if session.get('debug') == 1: return

        log_path = 'logs/request'
        log_file = getDate(format='%Y-%m-%d') + '.json'
        if not os.path.exists(log_path): os.makedirs(log_path)

        from flask import request
        log_data = {}
        log_data['date'] = getDate()
        log_data['ip'] = GetClientIp()+':'+str(request.environ.get('REMOTE_PORT'))
        log_data['method'] = request.method
        log_data['uri'] = request.full_path
        log_data['user-agent'] = request.headers.get('User-Agent')
        
        WriteFile(log_path + '/' + log_file,json.dumps(log_data) + "\n",'a+')
    except: pass



def get_menus():
    '''
        @name 获取菜单列表
        @author hwliang<2020-08-31>
        @return list
    '''
    from BTPanel import session
    data = json.loads(ReadFile('config/menu.json'))
    hide_menu = ReadFile('config/hide_menu.json')
    debug = session.get('debug')
    if hide_menu:
        hide_menu = json.loads(hide_menu)
        show_menu = []
        for i in range(len(data)):
            if data[i]['id'] in hide_menu: continue
            if data[i]['id'] == "memuAxterm":
                if debug: continue
            show_menu.append(data[i])
        data = show_menu
        del(hide_menu)
        del(show_menu)
    menus = sorted(data, key=lambda x: x['sort'])
    return menus

def get_path_size(path):
    """
    根据路径获取文件/目录大小
    @path 文件或者目录路径
    return int 
    """
    if not os.path.exists(path): return 0;
    if not os.path.isdir(path): return os.path.getsize(path)
    size_total = 0
    for nf in os.walk(path):
        for f in nf[2]:
            filename = nf[0] + '/' + f
            if not os.path.exists(filename): continue;
            if os.path.islink(filename): continue;
            size_total += os.path.getsize(filename)
    return size_total

def get_database_character(db_name):
    """
    获取mysql字符集
    @db_name 数据库名称
    return str 字符集
    """
    try:
        import panelMysql
        tmp = panelMysql.panelMysql().query("show create database `%s`" % db_name.strip())
        c_type = str(re.findall("SET\s+([\w\d-]+)\s",tmp[0][1])[0])
        c_types = ['utf8','utf-8','gbk','big5','utf8mb4']
        if not c_type.lower() in c_types: return 'utf8'
        return c_type
    except:
        return 'utf8'

def check_win_path(path):
    """
    检查Windows路径是否含有特殊字符
    @path 需检查的文件路径
    return bool
    """
    import re
    tmp = re.match('[a-zA-Z]:(.+)',path)
    if not tmp : return False
    if re.search('[\*\?\<\>\:\|\"\：]',tmp.groups()[0]): return False
    return True

def submit_panel_bug(err_msg = None):    
    """
    提交面板错误日志
    @err_msg 错误内容
    """
    try:                 
        from BTPanel import request
        import system
        if not err_msg: err_msg = get_error_info()

        pdata = {}
        pdata['err_info'] = err_msg
        pdata['path_full'] = request.full_path

        pdata['version'] = 'Windows-Panel-%s' % version()
        pdata['os'] = system.system().GetSystemVersion()
        pdata['py_version'] = sys.version
        pdata['install_date'] = int(os.stat('class/common.py').st_mtime)
        httpPost("http://www.bt.cn/api/panel/s_error",pdata,timeout=3)
    except : pass

#获取debug日志
def get_debug_log():
    from BTPanel import request
    return GetClientIp() +':'+ str(request.environ.get('REMOTE_PORT')) + '|' + str(int(time.time())) + '|' + get_error_info()

def version():
    """
    获取面板版本
    """
    try:
        version  = readFile('data/panel.version')
    except :
        version = '6.0.0'
    return version

def path_safe_check(path,force=True):
    """
    校验路径安全
    @path 校验路径
    @force 
    """
    if len(path) > 256: return False 
    checks = ['..','./','\\','%','$','^','&','*','~','#','"',"'",';','|','{','}','`']
    for c in checks:
        if path.find(c) != -1: return False
    if force:
        rep = r"^[\w\s\.\/-]+$"
        if not re.match(rep,path): return False
    return True

def get_pip_url():
    """
    自动适配pip源(os.getenv('APPDATA') + '/pip')
    """
    path = os.getenv('APPDATA') + '/pip'    
    if not os.path.exists(path): os.makedirs(path)
    if not os.path.exists(path + '/pip.ini'):
        nodes = ['https://mirrors.aliyun.com/pypi/simple','https://pypi.doubanio.com/simple','https://pypi.tuna.tsinghua.edu.cn/simple']
        curr_node = None
        for node in nodes:           
            start = time.time();
            ping =  10000
            ret = httpGet(node + '/0/',10)
            if ret.find(".whl") >= 0:  ping = time.time() - start
            
            if not curr_node: curr_node = {'ping':10000,'url':node }
            if ping < curr_node['ping']: curr_node = {'ping':ping,'url':node }
            if curr_node['ping'] < 50: break

        tmp = re.search('\/\/(.+?)\/',curr_node['url'])
        if tmp:
            host = tmp.groups()[0]
            config = '''[global]
index-url = %s

[install]
trusted-host = %s''' % (curr_node['url'],host)
            writeFile(path + '/pip.ini',config)
            return True
    return False

def copytree(src, dst):
    """
    重新拷贝目录方法
    @src 源目录
    @dst 新目录
    """
    import shutil
    names = os.listdir(src)
    if not os.path.exists(dst):  os.makedirs(dst)
    for name in names:
        srcname = os.path.join(src, name)
        dstname = os.path.join(dst, name)
        try:        
            if os.path.isdir(srcname):
                copytree(srcname, dstname)
            else:              
                shutil.copy2(srcname, dstname)
        except: pass


def move(sfile,dfile):
    """
    重写文件移动
    @sfile 源文件路径
    @dfile 新文件路径
    """
    dfile = dfile.replace('//','/')
    sfile = sfile.replace('//','/')
    import shutil
    if not os.path.exists(sfile): return False
    if dfile.rstrip('/') == sfile.rstrip('/'):  return False

    dfile.rstrip()
    if sfile.lower() == dfile.lower():
        os.rename(sfile,dfile);
        return True;

    is_dir = os.path.isdir(sfile)
    if not os.path.exists(dfile) or not is_dir:
        try:
            if os.path.exists(dfile): os.remove(dfile)        
        except :
            ExecShell("attrib -r {}".format(to_path(dfile)))  
            os.remove(dfile)       
        
        shutil.move(sfile, dfile)
    else:
        copytree(sfile,dfile)
        if os.path.exists(sfile):
            if is_dir: 
                shutil.rmtree(sfile,True)
            else:
                try:
                    os.remove(sfile)
                except :
                    ExecShell("attrib -r {}".format(to_path(dfile)))  
                    os.remove(sfile)                  
    return True

def format_error(msg):
    """
    格式化错误
    """
    if msg.find('页面文件太小') >=0:
        msg = "系统内存不足.";
    elif msg.find('No space left on device') >=0 :
        msg = '无法完成此操作，磁盘容量不足，请先清理或扩充.'
    
    return msg;

def sync_date(self,get):
    """
    同步系统时间
    """
    dateStr = HttpGet(GetConfigValue('home') + '/api/index/get_win_date')
    arrs = dateStr.split(' ')
    os.system('date {} && time {}'.format(arrs[0],arrs[1]))

def set_phpmyadmin_conf(port):
    """
    设置phpmyadmin连接端口
    @port mysql端口
    """
    dir_name = readFile('data/phpmyadminDirName.pl')
    if not dir_name: return True
        
    path = os.getenv("BT_SETUP") + '\\phpmyadmin\\' + dir_name
    conf = ''
    if not os.path.exists(path + '/config.inc.php'):
        if os.path.exists(path + '/config.sample.inc.php'): conf = readFile(path + '/config.sample.inc.php')
    else:
        conf = readFile(path + '/config.inc.php')
        
    if conf.find("$cfg['Servers'][$i]['port']") >= 0:
        conf = re.sub("\$cfg\[\'Servers\'\]\[\$i\]\[\'port\'\].+","$cfg['Servers'][$i]['port'] = '{}';".format(port),conf)    
    else:
        conf = conf.replace('''$cfg['Servers'][$i]['host'] = 'localhost';''','''$cfg['Servers'][$i]['host'] = 'localhost';
$cfg['Servers'][$i]['port'] = '%s';''' % (port))

    writeFile(path + '/config.inc.php',conf)
   

def get_run_python(shell):
    """
    获取运行python脚本
    @shell 执行命令
    """
    shell = shell.replace('[PYTHON]','"C:/Program Files/python/python.exe"')
    return shell

def get_run_pip(shell):
    """
    获取运行pip脚本
    @shell 执行命令
    """
    shell = shell.replace('[PIP]','"C:\Program Files\python\python.exe" -m pip')
    return shell

def tran_lang(msg,to_lang,from_lang = "CN"):
    """
    转换语言
    @msg 要转换的内容
    @to_lang 需要转换的语言
    @from_lang 原内容语言
    """
    try:
        from translate import Translator
    except :
        os.system(get_run_pip("[PIP] install translate"))
        from translate import Translator        

    translator= Translator(from_lang = from_lang, to_lang = to_lang)
    translation = translator.translate(msg)

    return translation

def en_punycode(domain):
    """
    中文域名转punycode
    @domain 要转换的域名
    """
    tmp = domain.split('.');
    newdomain = '';
    for dkey in tmp:
        #匹配非ascii字符
        match = re.search(u"[\x80-\xff]+",dkey);
        if not match: match = re.search(u"[\u4e00-\u9fa5]+",dkey);
        if not match:
            newdomain += dkey + '.';
        else:
            newdomain += 'xn--' + dkey.encode('punycode').decode('utf-8') + '.'
    return newdomain[0:-1];

def de_punycode(domain):
    """
    punycode 转中文域名
    @domain 要转换的域名
    """
    tmp = domain.split('.');
    newdomain = '';
    for dkey in tmp:
        if dkey.find('xn--') >=0:
            newdomain += dkey.replace('xn--','').encode('utf-8').decode('punycode') + '.'
        else:
            newdomain += dkey + '.'
    return newdomain[0:-1];

def import_cdn_plugin():
    """
    引用静态加速插件
    """
    plugin_path = 'plugin/static_cdn'
    if not os.path.exists(plugin_path): 
       
        return True
    try:
        import static_cdn_main
    except:
        sys.path.insert(0,plugin_path)
        import static_cdn_main
    

def get_cdn_hosts():
    """
    获取静态加速插件节点列表
    """
    if import_cdn_plugin(): return []
    import static_cdn_main
    return static_cdn_main.static_cdn_main().get_hosts(None)

def get_cdn_url():
    """
    获取当前选择的静态加速节点
    """
    try:
        from BTPanel import cache
        cdn_url = cache.get('cdn_url')
        if cdn_url: return cdn_url
        if import_cdn_plugin(): return False
        import static_cdn_main
        cdn_url = static_cdn_main.static_cdn_main().get_url(None)
       
        cache.set('cdn_url',cdn_url,3)
        return cdn_url
    except:
        return False

def set_cdn_url(cdn_url):
    """
    设置当前静态加速节点
    @cdn_url 当前选择的cdn节点
    """
    if not cdn_url: return False
    import_cdn_plugin()
    get = dict_obj()
    get.cdn_url = cdn_url
    import static_cdn_main
    static_cdn_main.static_cdn_main().set_url(get)
    return True

def get_page(count,p=1,rows=12,callback='',result='1,2,3,4,5,8'):
    """
    构造分页
    @count 总数量
    @p 当前第几页
    @rows 每页行数
    @callback 回调函数
    @result 构造结果
    """
    import page
    from BTPanel import request
    page = page.Page()
    info = { 'count':count,  'row':rows,  'p':p, 'return_js':callback ,'uri':request.full_path}
    data = { 'page': page.GetPage(info,result),  'shift': str(page.SHIFT), 'row': str(page.ROW) }
    return data

def is_ipv4(ip):
    """
    判断是否IPV4地址
    @ip ip地址
    return bool 
    """
    try:
        socket.inet_pton(socket.AF_INET, ip)
    except AttributeError:
        try:
            socket.inet_aton(ip)
        except socket.error:
            return False
        return ip.count('.') == 3
    except socket.error:
        return False
    return True
 
 
def is_ipv6(ip):
    """
    判断是否IPV6地址
    @ip ip地址
    return bool 
    """
    try:
        socket.inet_pton(socket.AF_INET6, ip)
    except socket.error:
        return False
    return True
  
def check_ip(ip):
    """
    判断是否IP地址(ipv4+ipv6)
    @ip ip地址
    return bool 
    """
    return is_ipv4(ip) or is_ipv6(ip)


def url_encode(data):
    if type(data) == str: return data
    import urllib
    if sys.version_info[0] != 2:
        pdata = urllib.parse.urlencode(data).encode('utf-8')
    else:
        pdata = urllib.urlencode(data)
    return pdata

def url_decode(data):
    if type(data) == str: return data
    import urllib
    if sys.version_info[0] != 2:
        pdata = urllib.parse.urldecode(data).encode('utf-8')
    else:
        pdata = urllib.urldecode(data)
    return pdata

def unzip(src_path,dst_path):
    """
    解压目录
    @src_path zip文件路径
    @dst_path 解压路径
    """
    import zipfile
    zip_file = zipfile.ZipFile(src_path)  
    for names in zip_file.namelist():  
        zip_file.extract(names,dst_path)      
    zip_file.close()
    return True

def set_func(key):
    """
    设置指定key的操作时间
    @key 面板访问函数
    """
    path = 'data/func.json'
    data = {}
    try:
        data = json.loads(readFile(path))
    except :pass
    if not key in data: 
        data[key] = {}        
        data[key]['time'] = 0
        data[key]['count'] = 0
    data[key]['time'] = int(time.time())
    data[key]['count'] += 1
    writeFile(path,json.dumps(data))

def get_func(key):
    """
    获取指定功能的操作时间
    @key 面板函数
    """
    path = 'data/func.json'
    ret = {}
    ret['count'] = 0
    ret['time'] = 0
    if not os.path.exists(path): return ret
    data = {}
    try:
        data = json.loads(readFile(path))
    except : pass
    if not key in data: return ret    
    return data[key]

def find_user(name):
    """
    查询系统用户是否存在
    @name 系统用户
    """
    resume = 0
    while True:
        data, total, resume = win32net.NetUserEnum(None, 3, win32netcon.FILTER_NORMAL_ACCOUNT, resume)
        for user in data:
            if user['name'].lower() == name.lower():
                return user
        if not resume: break

    return False

def add_user(name,pwd, ps = ''):
    """
    添加系统用户
    @name 用户名
    @pwd 密码
    @ps 备注
    """
    try:
        d = {}
        d['name'] = name.lower()
        d['password'] = pwd
        d['comment'] = ps
        d['flags'] = win32netcon.UF_NORMAL_ACCOUNT | win32netcon.UF_SCRIPT
        d['priv'] = win32netcon.USER_PRIV_USER
        win32net.NetUserAdd(None, 1, d)
       
        #设置用户允许登录服务
        handle = win32security.LsaOpenPolicy(None, win32security.POLICY_ALL_ACCESS)
        sid_obj, domain, tmp = win32security.LookupAccountName(None, name.lower())
        win32security.LsaAddAccountRights(handle, sid_obj, ('SeServiceLogonRight',) )
        win32security.LsaClose(handle) 

        return True,None
    except :
        return False,get_error_info()

def change_user_pwd(name,pwd):
    """
    修改用户密码
    @name 系统用户
    @pwd 新密码
    """
    try:
        name = name.lower()
        data = find_user(name)
        if data:
            data['password'] = pwd
            win32net.NetUserSetInfo(None, name, 1, data)
            return True,None
        return False,'【{}】用户不存在'.format(name)
    except :
        return False,get_error_info()   

def del_user(name):
    """
    删除系统用户
    @name 系统用户名
    """    
    name = name.lower()
    bt_user = ["administrator"]
    if name in bt_user: return False,'系统用户不允许删除.'
    try:
        win32net.NetUserDel(None,name)
        return True,None
    except :
        return False,get_error_info()

def init_msg(module):
    """
    初始化消息通道
    @module 消息通道模块名称
    """
    import os,sys
    if not os.path.exists('class/msg'): os.makedirs('class/msg')
    panelPath = os.getenv('BT_PANEL')

    sfile = 'class/msg/{}_msg.py'.format(module)
    if not os.path.exists(sfile): return False
    sys.path.insert(0,"{}/class/msg".format(panelPath))

    msg_main = __import__('{}_msg'.format(module))
    try:
        mod_reload(msg_main)
    except: pass
    return  eval('msg_main.{}_msg()'.format(module));

#获取证书哈希
def get_cert_data(path):
    import panelSSL
    get = dict_obj()
    get.certPath = path
    data = panelSSL.panelSSL().GetCertName(get)
    return data


def set_error_num(key,empty = False,expire=3600):
    '''
        @name 设置失败次数(每调用一次+1)
        @author hwliang<2020-08-21>
        @param key<string> 索引
        @param empty<bool> 是否清空计数
        @param expire<int> 计数器生命周期(秒)
        @return bool
    '''
    from BTPanel import cache
    key = md5(key)
    num = cache.get(key)
    if not num:
        num = 0
    else:
        if empty:
            cache.delete(key)
            return True
    cache.set(key,num + 1,expire)
    return True

def get_error_num(key,limit=False):
    '''
        @name 获取失败次数
        @author hwliang<2020-08-21>
        @param key<string> 索引
        @param limit<False or int> 如果为False，则直接返回失败次数，否则与失败次数比较，若大于失败次数返回True，否则返回False 
        @return int or bool
    '''
    from BTPanel import cache
    key = md5(key)
    num = cache.get(key)
    if not num: num = 0
    if not limit: 
        return num
    if limit > num:
        return True
    return False

def long2ip(ips):
    '''
        @name 将整数转换为IP地址
        @author hwliang<2020-06-11>
        @param ips string(ip地址整数)
        @return ipv4
    '''
    i1 = int(ips / (2 ** 24))
    i2 = int((ips - i1 * ( 2 ** 24 )) / ( 2 ** 16 ))
    i3 = int(((ips - i1 * ( 2 ** 24 )) - i2 * ( 2 ** 16 )) / ( 2 ** 8))
    i4 = int(((ips - i1 * ( 2 ** 24 )) - i2 * ( 2 ** 16 )) - i3 * ( 2 ** 8))
    return "{}.{}.{}.{}".format(i1,i2,i3,i4)

def ip2long(ip):
    '''
        @name 将IP地址转换为整数
        @author hwliang<2020-06-11>
        @param ip string(ipv4)
        @return long
    '''
    ips = ip.split('.')
    if len(ips) != 4: return 0
    iplong = 2 ** 24 * int(ips[0]) + 2 ** 16 * int(ips[1])  + 2 ** 8 * int(ips[2])  + int(ips[3])
    return iplong

#提交关键词
def submit_keyword(keyword):
    pdata = {"keyword":keyword}
    httpPost(GetConfigValue('home') + '/api/panel/total_keyword',pdata)

#统计关键词
def total_keyword(keyword):
    import threading
    p = threading.Thread(target=submit_keyword,args=(keyword,))
    p.setDaemon(True)
    p.start()

#获取sessionid
def get_session_id():
    from BTPanel import request

    session_id = request.cookies.get('SESSIONID')
    if not re.findall(r"^([\w\.-]{64,64})$",session_id):
        return GetRandomString(64)
    return session_id


def chdck_salt():
    '''
        @name 检查所有用户密码是否加盐，若没有则自动加上
        @author hwliang<2020-07-08>
        @return void
    '''

    if not M('sqlite_master').where('type=? AND name=? AND sql LIKE ?', ('table', 'users','%salt%')).count():
        M('users').execute("ALTER TABLE 'users' ADD 'salt' TEXT",())
    u_list = M('users').where('salt is NULL',()).field('id,username,password,salt').select()
    for u_info in u_list:
        salt = GetRandomString(12) #12位随机
        pdata = {}
        pdata['password'] = md5(md5(u_info['password']+'_bt.cn') + salt)
        pdata['salt'] = salt
        M('users').where('id=?',(u_info['id'],)).update(pdata)


def get_login_token():
    token_s = readFile('data/login_token.pl')
    if not token_s: return GetRandomString(32)

    return token_s

def get_sess_key():
    from BTPanel import session
    return md5(get_login_token() + session.get('request_token_head',''))

def password_salt(password,username=None,uid=None):
    '''
        @name 为指定密码加盐
        @author hwliang<2020-07-08>
        @param password string(被md5加密一次的密码)
        @param username string(用户名) 可选
        @param uid int(uid) 可选
        @return string
    '''
    chdck_salt()
    if not uid:
        if not username:
            raise Exception('username或uid必需传一项')
        uid = M('users').where('username=?',(username,)).getField('id')
    salt = M('users').where('id=?',(uid,)).getField('salt')
    return md5(md5(password+'_bt.cn')+salt)

def get_mysql_info():
    """
    获取以安装数据库信息
    """
    path = get_server_path('mysql')
    name = re.search('([MySQL|MariaDB-]+\d+\.\d+)',path).groups()[0] 
    myconf = readFile(GetConfigValue('setup_path') + '/mysql/' + name + '/my.ini');
    rep = "port\s*=\s*([0-9]+)"
    data = {}
    data['port'] = int(re.search(rep,myconf).groups()[0]);
    data['name'] = name
    data['path'] = GetConfigValue('setup_path') + '/mysql/' + data['name']
    data['version'] =  re.search("(\d*\.\d*)",name).groups()[0];
    return data

def get_net_version():
    """
    获取net版本
    """
    netV = '45'
    if os.path.exists('data/net'): 
        netV = readFile('data/net')  
    return netV

def get_py_version():
    """
    获取加密插件版本
    """
    import sys
    v = 'cp{}{}'.format(sys.version_info.major,sys.version_info.minor)

    return v

def clear_is_read(path):
    if os.path.isdir(path):
        ExecShell("attrib -r {}/*.* /s /d".format(to_path(path)))  
    else:
        ExecShell("attrib -r {} /s /d".format(to_path(path)))  


def get_update_file():

    local_path = '{}/class/panel_update.py'.format(os.getenv('BT_PANEL'))
    downloadFileByWget('{}/win/install/panel_update.py'.format(get_url()),local_path)
    if os.path.getsize(local_path) < 64: return False;

    update_obj = __import__('panel_update')                       
    mod_reload(update_obj)

    return True

def file_unlock(filename):
    """
    解除文件占用
    @filename 文件路径
    """
    for proc in psutil.process_iter():
        if proc.pid < 200: continue #1000以内为系统进程
        try:
            for x in proc.open_files():              
                if format_path(filename.strip()) == format_path(x.path.strip()):                    
                    proc.kill()
        except : pass  

def get_registry_value(key, subkey, value):
    """
    读取注册表信息
    @key 注册表类型
    @subkey 注册表路径
    @value 注册表具体key值
    """
    import winreg
    key = getattr(winreg, key)
    handle = winreg.OpenKey(key, subkey)
    (value, type) = winreg.QueryValueEx(handle, value)
    return value

def get_system_version(info = False):
    """
    取操作系统版本
    """
    try:            
        import public,platform
        bit = 'x86';
        if is_64bitos(): bit = 'x64'

        def get(key):
            return get_registry_value("HKEY_LOCAL_MACHINE", "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", key)
        os = get("ProductName")
        build = get("CurrentBuildNumber")

        version = "%s (build %s) %s (Py%s)" % (os, build,bit,platform.python_version())
        if info: return version

        tmp = re.search('Windows\s+Server\s+(\d+)',version)
        if tmp: return tmp.groups()[0]

        return None
    except Exception as ex:
        WriteLog('获取系统版', '获取系统版本失败,注册表无法打开,错误详情 ->>' + str(ex));
        return None

def aes_encrypt(data,key):
    import panelAes  
    aes_obj = panelAes.aescrypt_py3(key)
    return aes_obj.aesencrypt(data)

def aes_decrypt(data,key):
    import panelAes  
    aes_obj = panelAes.aescrypt_py3(key)
    return aes_obj.aesdecrypt(data)

def get_ipaddress():
    '''
        @name 获取本机IP地址
        @author hwliang<2020-11-24>
        @return list
    '''
    ipa_tmp = ExecShell("ip a |grep inet|grep -v inet6|grep -v 127.0.0.1|grep -v 'inet 192.168.'|grep -v 'inet 10.'|awk '{print $2}'|sed 's#/[0-9]*##g'")[0].strip()
    iplist = ipa_tmp.split('\n')
    return iplist

def run_thread(fun,args = (),daemon=False):
    '''
        @name 使用线程执行指定方法
        @author heliang<2020-10-27>
        @param fun {def} 函数对像
        @param args {tuple} 参数元组
        @param daemon {bool} 是否守护线程
        @return bool
    '''
    import threading
    p = threading.Thread(target=fun,args=args)
    p.setDaemon(daemon)
    p.start()
    return True


#加密字符串
def en_crypt(key,strings):
    try:
        if type(strings) != bytes: strings = strings.encode('utf-8')
        from cryptography.fernet import Fernet
        f = Fernet(key)
        result = f.encrypt(strings)
        return result.decode('utf-8')
    except:
        #print(get_error_info())
        return strings

#解密字符串
def de_crypt(key,strings):
    try:
        if type(strings) != bytes: strings = strings.decode('utf-8')
        from cryptography.fernet import Fernet
        f = Fernet(key)
        result =  f.decrypt(strings).decode('utf-8')
        return result
    except:
        #print(get_error_info())
        return strings

def check_domain_cloud(domain):
    run_thread(cloud_check_domain,(domain,))
    
def cloud_check_domain(domain):
    '''
        @name 从云端验证域名的可访问性,并将结果保存到文件
        @author hwliang<2020-12-10>
        @param domain {string} 被验证的域名
        @return void
    '''
    try:
        check_domain_path = 'data/check_domain/'
        if not os.path.exists(check_domain_path):
            os.makedirs(check_domain_path,384)
        result = httpPost('https://www.bt.cn/api/panel/check_domain',{"domain":domain})
        cd_file = check_domain_path + domain +'.pl'
        writeFile(cd_file,result)
    except:
        pass

def isOpen(port):
    #检查端口是否占用
    import socket
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    try:
        s.connect(('127.0.0.1',int(port)))
        s.shutdown(2)
        return True
    except:
        return False

def get_root_domain(domain_name):
    '''
        @name 根据域名查询根域名和记录值
        @author cjxin<2020-12-17>
        @param domain {string} 被验证的根域名
        @return void
    '''
    top_domain_list = ['.ac.cn', '.ah.cn', '.bj.cn', '.com.cn', '.cq.cn', '.fj.cn', '.gd.cn',
                        '.gov.cn', '.gs.cn', '.gx.cn', '.gz.cn', '.ha.cn', '.hb.cn', '.he.cn',
                        '.hi.cn', '.hk.cn', '.hl.cn', '.hn.cn', '.jl.cn', '.js.cn', '.jx.cn',
                        '.ln.cn', '.mo.cn', '.net.cn', '.nm.cn', '.nx.cn', '.org.cn','.cn.com']
    old_domain_name = domain_name
    top_domain = "."+".".join(domain_name.rsplit('.')[-2:])
    new_top_domain = "." + top_domain.replace(".", "")
    is_tow_top = False
    if top_domain in top_domain_list:
        is_tow_top = True
        domain_name = domain_name[:-len(top_domain)] + new_top_domain

    if domain_name.count(".") > 1:
        zone, middle, last = domain_name.rsplit(".", 2)
        if is_tow_top:
            last = top_domain[1:]
        root = ".".join([middle, last])
    else:
        zone = ""
        root = old_domain_name
    return root, zone

def query_dns(domain,dns_type = 'A',is_root = False):
    '''
        @name 查询域名DNS解析
        @author cjxin<2020-12-17>
        @param domain {string} 被验证的根域名
        @param dns_type {string} dns记录
        @param is_root {bool} 是否查询根域名
        @return void
    '''
    try:
        import dns.resolver
    except :
        os.system(get_run_pip('[PIP] install dnspython'))
        import dns.resolver

    if is_root: domain,zone = get_root_domain(domain)
    try:
        ret = dns.resolver.query(domain, dns_type)           
        data = []
        for i in ret.response.answer:            
            for j in i.items:
                tmp = {}
                tmp['flags'] = j.flags
                tmp['tag'] = j.tag.decode()
                tmp['value'] = j.value.decode()
                data.append(tmp)
        return data
    except :
        return False

def re_python_pro(port):
    """
    @port 占用进程
    """
    for proc in psutil.process_iter():        
        if proc.name() == 'python.exe':           
            for x in proc.connections():
                if x.laddr.port == port:
                    try:
                       proc.kill()
                    except: pass
                    time.sleep(1);
    


#检查App和小程序的绑定
def check_app(check='app'):
    path = os.getenv('BT_PANEL')
    if check=='app':
        try:
            if not os.path.exists(path + '/data/user.json') and os.path.exists(path + '/config/api.json') and not os.path.exists(path + '/plugin/app/user.json'):
              
                return False

            if os.path.exists(path + '/plugin/app/user.json'):
                wxapp = json.loads(readFile(path+'/plugin/app/user.json'))
                if wxapp:return True
            if os.path.exists(path+'/data/user.json'):
                app_info = json.loads(readFile(path+'/data/user.json'))
                if app_info:return True
            if os.path.exists(path+'/config/api.json'):
                btapp_info = json.loads(readFile(path+'/config/api.json'))
                
                if not  btapp_info['open']:return False
                if not 'apps' in btapp_info:return False
                if not btapp_info['apps']:return False
                return True
            return False
        except:
            return False
    elif check=='wxapp':
        if not os.path.exists(path+'/plugin/app/user.json'):return False
        app_info = json.loads(readFile(path+'/plugin/app/user.json'))
        if not app_info: return False
        return True

#取通用对象
class dict_obj:
    def __contains__(self, key):
        return getattr(self,key,None)
    def __setitem__(self, key, value): setattr(self,key,value)
    def __getitem__(self, key): return getattr(self,key,None)
    def __delitem__(self,key): delattr(self,key)
    def __delattr__(self, key): delattr(self,key)
    def get_items(self): return self