#coding: utf-8
# +-------------------------------------------------------------------
# | 宝塔Windows面板 
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: 沐落 <cjx@bt.cn>
# +-------------------------------------------------------------------

import win32serviceutil,win32service,win32event
import os,sys,psutil,time,threading,subprocess


class btService(win32serviceutil.ServiceFramework): 
    #服务名 
    _svc_name_ = "btPanel"
    #服务在windows系统中显示的名称 
    _svc_display_name_ = "btPanel"
    #服务的描述 
    _svc_description_ = "用于运行宝塔Windows面板主程序,停止后面板将无法访问."  

    def __init__(self, args): 

        win32serviceutil.ServiceFramework.__init__(self, args) 
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None) 
        self.run = True

   
    def SvcDoRun(self): 

        path = os.getenv('BT_PANEL')        
        os.chdir(path)
        sys.path.insert(0,path + "/class/")
        import public

        try:
            retry_num = 0 #重试次数

            p_file = '{}/logs/panel.pid'.format(path)    
            
            pid = public.readFile(p_file)
            if pid: os.system("taskkill /t /f /pid {}".format(pid))
            
            import subprocess
            self.p = subprocess.Popen(['C:\Program Files\python\python.exe', path + '/runserver.py'])
            public.writeFile(p_file,str(self.p.pid))

            #添加守护，防止进程被中断
            while self.run:
                try:
                    pro = psutil.Process(self.p.pid)            
                    if not pro:  
                        self.p = subprocess.Popen(['C:\Program Files\python\python.exe', path + '/runserver.py'])     
                        public.writeFile(p_file,str(self.p.pid))
                    if retry_num >= 3: self.run = False;                        
                except :pass       
                time.sleep(1)
             
            # 等待服务被停止 
            win32event.WaitForSingleObject(self.hWaitStop, win32event.INFINITE)
        except :
            fp = open('{}/data/panelError.log'.format(path), mode = 'w+',encoding = 'utf-8');
            fp.write('ERROR: 计算机名不允许包含中文，请修改后重启服务器。')
            fp.close()
     
    def SvcStop(self): 
        os.system("taskkill /t /f /pid %s" % self.p.pid)
        # 先告诉SCM停止这个过程 
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING) 
        # 设置事件 
        win32event.SetEvent(self.hWaitStop)
        self.run = False

if __name__ == '__main__':
    path = os.getenv('BT_PANEL')
   

    if len(sys.argv) >= 2:       
        if not path:            
            path = os.path.dirname(sys.argv[0])
            os.environ['BT_PANEL'] = path
            if not path:
                print('ERROR:安装失败，找不到环境变量【BT_PANEL】.')
                exit()
        win32serviceutil.HandleCommandLine(btService) 
    else:     
        is_debug = os.path.exists(path + '/data/debug.pl')

        if not is_debug:
            #必须放在前面，否则requests模块无效
            try:
                from gevent import monkey
            except :
                os.system(public.get_run_pip('[PIP] install gevent'))
                from gevent import monkey
            monkey.patch_all() 

        os.chdir(path)
        sys.path.insert(0,path + "/class/")
        from os import environ

        from BTPanel import app,sys
        import public
                   
        PORT = 8888
        filename = path + '/data/port.pl'
        if os.path.exists(filename):
            PORT = int(public.readFile(filename))         
        HOST = '0.0.0.0'      

        if is_debug:
            app.run(host = HOST,port = PORT,debug = True,threaded=True)
        else:                        
            from gevent import pywsgi             
            try:
                from geventwebsocket.handler import WebSocketHandler
            except :
                os.system(public.get_run_pip('[PIP] install gevent-websocket'))                
                from geventwebsocket.handler import WebSocketHandler
            
            server = pywsgi.WSGIServer((HOST, PORT),app,handler_class=WebSocketHandler)
            server.serve_forever()
